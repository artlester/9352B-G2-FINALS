<?php
	require('db.php');
	require('session.php');
?> 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Homepage</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/userbar.css">
</head>
<body style="margin:0;">
	<?php include 'userbar.php' ?>
	<div>
	<div style="margin:0;padding:0;width:100%;display:flex;">
			<div style="width:80%;float:left;"><?php include 'the-transactions.php'?></div>
			<div style="width:20%;background-color:#5c5c3d;float:left;"><?php include 'pick-date.php'?></div>
	</div>
	</div>
	<footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
	<!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
	</body>	
	</html>
