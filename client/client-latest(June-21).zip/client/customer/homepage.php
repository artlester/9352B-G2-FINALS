<?php include 'session.php' ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Homepage</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/homepage.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/userbar.css">
</head>
<body>
    <?php include 'userbar.php'; ?>
    <div class="welcome text-center" id="welcome">
        <br>
        <h1 id="logo">Audirentur</h1>
        <h3 id="logo">The online rental for sound systems at the best and most affordable price!</h3>
        <br><br>
        <form action="showProductsSear.php" method="POST">
            <input type="text" name="search" placeholder="Search...">
            <button type="submit" name="submit-search">Search</button> 
		</form>
		<!--form action="search.php" method="POST">
            <div class="container input-group">
                    <input class="form-control py-2" type="search" name="key" placeholder="Search for systems..." required>
                    <div class="input-group-append">
                        <button class="btn btn-outline-secondary" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
            </div>
        </form-->
    </div>
    <div class="categories text-center" id="categories">
        <br>
        <h1>Categories</h1>
        <div class="section group text-center">
            <div class="col span_1_of_5">
                <a href="http://customer.audirentur.com/showProductsCat.php?category=speaker" class="text-dark">
                    <img src="http://customer.audirentur.com/img/boombox.png">
                    <br><br>
                    <h3>Speakers</h3>
                </a>
            </div>
            <div class="col span_1_of_5">
                <a href="http://customer.audirentur.com/showProductsCat.php?category=equalizer" class="text-dark">
                    <img src="http://customer.audirentur.com/img/mixing.png">
                    <br><br>
                    <h3>Equalizer</h3>
                </a>
            </div>
            <div class="col span_1_of_5">
                <a href="http://customer.audirentur.com/showProductsCat.php?category=amplifier" class="text-dark">
                    <img src="http://customer.audirentur.com/img/amplifier.png">
                    <br><br>
                    <h3>Amplifiers</h3>
                </a>
            </div>
            <div class="col span_1_of_5">
                <a href="http://customer.audirentur.com/showProductsCat.php?category=bundle" class="text-dark">
                    <img src="http://customer.audirentur.com/img/sound-system.png">
                    <br><br>
                    <h3>Bundles</h3>
                </a>
            </div>  
        </div>
    </div>
	<div> 
	<?php include 'display.php'?>
	</div>
    <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>
</html>