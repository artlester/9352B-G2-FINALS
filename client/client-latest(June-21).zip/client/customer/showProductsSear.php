<?php include 'session.php' ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Homepage</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/userbar.css">
</head>
<body>
    <?php include 'userbar.php' ?>
    <div id="grad-bg">
        <br><br>
		<center>
		<!--?php include 'advertisement.html';?-->
		</center>
		<br>
        <form action="showProductsSear.php" method="POST">
            <input type="text" name="search" placeholder="Search...">
            <button type="submit" name="submit-search">Search</button> 
		</form>
		<center>
        <br><br>
    </div>
    <div class="container-fluid bg-black" id="bg-black">
        <div class="container">
            <nav class="nav nav-pills nav-fill">
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/categories.php?category=speaker">Speakers</a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/categories.php?category=equalizer">Equalizers</a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/categories.php?category=amplifier">Amplifiers</a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/categories.php?category=bundle">Bundles</a>
            </nav>
        </div>
    </div>
    <br>
    <div class="container">
        <!--h5>Filter Search</h5>
        <form action="filterSearch.php" method="POST">
            <div class="row">
                <div class="col">
                    <label for="startBudget">&nbsp; &nbsp; Starting Budget</label>
                </div>
                <div class="col">
                    <input type="text" class="form-control" name="startBudget" id="startBudget" placeholder="e.g. 0" style="width:200px;">
                </div>
                <div class="col">
                    <label for="startBudget">&nbsp; &nbsp; Ending Budget</label>
                </div>
                <div class="col">
                    <input type="text" class="form-control" name="endBudget" id="endBudget" placeholder="e.g. 10000" style="width:200px;">
                </div>
            </div>
        </form>
    </div>
    <!--?php
        if(isset($_GET['key'])){
            $query = "SELECT sounds.sound_id, sounds.name, sounds.price, sounds.product_image, sounds.date_availability, sounds.duration, categories.category, CONCAT('ven_first_name',' ','ven_last_name') AS ven_name FROM sounds NATURAL JOIN categorysound NATURAL JOIN categories NATURAL JOIN vendors WHERE CONCAT('sounds.name', 'sounds.price', 'sounds.date_availability', 'sounds.duration', 'categories.category', 'ven_first_name', 'ven_last_name') LIKE '%" . $_GET['key'] . "%';";            
        }elseif(isset($_GET['category'])) {
            $query = "SELECT sounds.sound_id, sounds.name, sounds.price, sounds.product_image, sounds.date_availability, sounds.duration, categories.category, CONCAT('ven_first_name',' ','ven_last_name') AS ven_name FROM sounds NATURAL JOIN categorysound NATURAL JOIN categories NATURAL JOIN vendors WHERE categories.category=" . $_GET['category'];
        }else {
            header("location:http://customer.audirentur.com");
        }
    ?-->
	<div> 
	<?php include 'search.php'?>
	</div>
	
    <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>