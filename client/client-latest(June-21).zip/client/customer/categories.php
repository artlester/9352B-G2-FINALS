<?php include('db.php'); ?>

<?php
    $category = $_GET['category'];
    switch ($category) {
            
        case "speaker": 
            $sql ="SELECT 
                        *
                    FROM
                        sounds s
                            JOIN
                        categorysound cs ON s.sound_id = cs.sound_id
                            JOIN
                        categories c ON c.category_id = cs.category_id
                    WHERE
                        category = 'speaker'"; 
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
            
             if($queryResults >0){
				 $count=1;
                while ($row = mysqli_fetch_array($result)){
                    echo "<a href='speaker.php?category=speaker'>";
                    ?>
            
            
            <form style="width:500px;float:left;padding:10px;font-size:30px;">
					<div style="border:1px solid #333; border-radius:5px; padding:10px; " align="center">
					<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $row['product_image']).'" 
					style="width:400px;height:300px;"/>'?>
					<br />
						<h2><?php echo $row['name']; ?></h2>
                        <p>Duration: <?php echo $row['duration']; ?> days</p>
                        <b>Available: <?php echo $row['date_availability'];?>
				        </b>
                        <p>Status: <?php echo $row['status']; ?></p>
                                    
                    </div>
				</form>
            
            <?php
                                
                $count++;
				}  
                }else{
                echo " There are no results matching your search!";
            }  
            
            break; 
            
            
            
        case "amplifier": 
            $sql ="SELECT 
                        *
                    FROM
                        sounds s
                            JOIN
                        categorysound cs ON s.sound_id = cs.sound_id
                            JOIN
                        categories c ON c.category_id = cs.category_id
                    WHERE
                        category = 'amplifier'"; 
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
            
             if($queryResults >0){
                while ($row = mysqli_fetch_assoc($result)){
                    echo "<a href='amplifier.php?category=amplifier'>";
                    ?>
            
            
            <form style="width:500px;float:left;padding:10px;font-size:30px;">
					<div style="border:1px solid #333; border-radius:5px; padding:10px; " align="center">
					<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $row['product_image']).'" 
					style="width:400px;height:300px;"/>'?>
					<br />
						<h2><?php echo $row['name']; ?></h2>
                        <p>Duration: <?php echo $row['duration']; ?> days</p>
                        <b>Available: <?php echo $row['date_availability'];?>
				        </b>
                        <p>Status: <?php echo $row['status']; ?></p>
                                    
                    </div>
				</form>
            
            <?php
                                
                }  
                }else{
                echo " There are no results matching your search!";
            }  
            
            break;
            
            
            
        case "bundle": 
            
            $sql ="SELECT 
                        *
                    FROM
                        sounds s
                            JOIN
                        categorysound cs ON s.sound_id = cs.sound_id
                            JOIN
                        categories c ON c.category_id = cs.category_id
                    WHERE
                        category = 'bundle'"; 
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
            
            if($queryResults >0){
                while ($row = mysqli_fetch_assoc($result)){
                    echo "<a href='bundle.php?category=bundle'>";
                    ?>
            
            
            <form style="width:500px;float:left;padding:10px;font-size:30px;">
					<div style="border:1px solid #333; border-radius:5px; padding:10px; " align="center">
					<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $row['product_image']).'" 
					style="width:400px;height:300px;"/>'?>
					<br />
						<h2><?php echo $row['name']; ?></h2>
                        <p>Duration: <?php echo $row['duration']; ?> days</p>
                        <b>Available: <?php echo $row['date_availability'];?>
				        </b>
                        <p>Status: <?php echo $row['status']; ?></p>
                                    
                    </div>
				</form>
            
            <?php
                                
                }  
                }else{
                echo " There are no results matching your search!";
            }  
            
            break; 
            
            
            
        case "equalizer": 
            
            $sql ="SELECT 
                        *
                    FROM
                        sounds s
                            JOIN
                        categorysound cs ON s.sound_id = cs.sound_id
                            JOIN
                        categories c ON c.category_id = cs.category_id
                    WHERE
                        category = 'equalizer'"; 
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
            
            if($queryResults >0){
                while ($row = mysqli_fetch_assoc($result)){
                    echo "<a href='equalizer.php?category=equalizer'>";
                    ?>
            
            
            <form style="width:500px;float:left;padding:10px;font-size:30px;">
					<div style="border:1px solid #333; border-radius:5px; padding:10px; " align="center">
					<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $row['product_image']).'" 
					style="width:400px;height:300px;"/>'?>
					<br />
						<h2><?php echo $row['name']; ?></h2>
                        <p>Duration: <?php echo $row['duration']; ?> days</p>
                        <b>Available: <?php echo $row['date_availability'];?>
				        </b>
                        <p>Status: <?php echo $row['status']; ?></p>
                                    
                    </div>
				</form>
            
            <?php
                                
                }  
                }else{
                echo " There are no results matching your search!";
            }  
            
            break; 
            
            
        default: echo "None";
    }
?>