<?php include 'db.php'?>
<?php
         $sql ="SELECT name, duration, status, product_image, DATE_FORMAT(date_availability, '%Y,%M %d') as date_availability FROM sounds ";
               $result=mysqli_query($mysqli,$sql);
               $queryResults=mysqli_num_rows($result);
                    if($queryResults > 0){
						
			?>
			<div>
<?php			
						$count=1;
                        while($row = mysqli_fetch_array($result)){
            ?>
			
				<form style="width:500px;float:left;padding:10px;font-size:25px;">
					<div style="border:1px solid #333; border-radius:5px; padding:10px; " align="center">
					<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $row['product_image']).'" 
					style="width:400px;height:300px;"/>'?>
					<br />
						<h1><?php echo $row['name']; ?></h1>
                        <hr>
						<p>Duration: <?php echo $row['duration']; ?> days</p>
                        <b>Available: 
						<?php echo $row['date_availability'];?>
						</b>
                        <p>Status: <i><?php echo strtoupper($row['status']); ?></i></p>
                        <input type="button" value="VIEW" style="padding: 0 15px 0 15px;"></input>           
                    </div>
				</form>
				
				<?php
                        $count++;
						} 
						?>
						</div>
				<?php
                    }
                ?>  