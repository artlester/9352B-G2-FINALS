<?php include('db.php'); ?>
<h1>Search Results:</h1>

<div class="results-container">
     
    <?php
        //kung may nalagay na sa search equequery niya yun
        if(isset($_POST['submit-search'])){
            
            $search = mysqli_real_escape_string($mysqli, $_POST['search']);
            $sql = "SELECT *
                FROM
                    sounds s
                        JOIN
                    categorysound cs ON s.sound_id = cs.sound_id
                        JOIN
                    categories c ON c.category_id = cs.category_id
                where c.category LIKE '%$search%' OR s.name LIKE '%$search%'
                ORDER BY s.status";
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
    
            echo "There are " .$queryResults. " results!<br>";
			
			
            if($queryResults >0){
                while ($row = mysqli_fetch_assoc($result)){
					?>
					<div style="float:left;">
					<form style="width:500px;float:left;padding:10px;font-size:25px;">
					<div style="border:1px solid #333; border-radius:5px; padding:10px; " align="center">
					<!--a href="product.php?title='.$row['name'].'&category='.$row['category'].'"-->
		<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $row['product_image']).'" style="width:400px;height:300px;"/>'?>
					<br/>
						<h1><?php echo $row['name']; ?></h1>
                        <hr>
						<p>Duration: <?php echo $row['duration']; ?> days</p>
                        <b>Available: 
						<?php echo $row['date_availability'];?>
						</b>
                        <p>Status: <i><?php echo strtoupper($row['status']); ?></i></p>
                        <input type="button" value="VIEW" style="padding: 0 15px 0 15px;"></input>           
                    </div>
				</form>
				</div>
					<?php
					
                }  
                } 
            }else{
                echo " There are no results matching your search!";
            }
        
    ?>

</div>