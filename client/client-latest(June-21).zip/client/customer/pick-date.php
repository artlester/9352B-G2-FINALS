<div style="text-align:center;">

<div style="background-color:whitesmoke;overflow-y:scroll;max-height:300px;">
<?php
$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date, rentals.status, sounds.name 
					FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
					INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
					WHERE customers.cust_username= '$user' AND Date(rental_date) = Date(NOW())";
			$result = mysqli_query($mysqli, $query);
			$queryresults = mysqli_num_rows($result);
?>

		<h2>Today's Transactions</h2>
	<?php 
	
			if ($queryresults !=0){
			$no=1;
			while ($row = mysqli_fetch_array($result)){
				echo '<hr><form>
						
						<h3>'.$row['name'].'</h3>
						<p><b>Rental Date: </b>'.$row['rental_date'].'</p>
						<p><b>Return Date: </b>'.$row['return_date'].'</p>
						<p><b>Status: </b>'.$row['status'].'</p>
						
						</form>';
					$no++;
			}
			}else{
			echo '<hr><p style="font-size:30px;">NONE</p>';
			}
		?>
</div>
<br>
<div style="background-color:whitesmoke;overflow-y:scroll;max-height:300px;">
		<h2>This Month Transactions</h2>
		<hr>
	<?php
$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date, rentals.status, sounds.name 
					FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
					INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
					WHERE customers.cust_username= '$user' AND rentals.rental_date > DATE_SUB(NOW(), INTERVAL 1 MONTH);";
			$result = mysqli_query($mysqli, $query);
			$queryresults = mysqli_num_rows($result);
			if ($queryresults !=0){
			$no=1;
			while ($row = mysqli_fetch_array($result)){
				echo '<hr><form>
						
						<h3>'.$row['name'].'</h3>
						<p><b>Rental Date: </b>'.$row['rental_date'].'</p>
						<p><b>Return Date: </b>'.$row['return_date'].'</p>
						<p><b>Status: </b>'.$row['status'].'</p>
						
						</form>';
					$no++;
			}
			}else{
			echo '<hr><p style="font-size:30px;">NONE</p>';
			}
?>	
</div>
<br>
<div style="background-color:whitesmoke;overflow-y:scroll;max-height:310px;">
	<form style="padding-top:20px;background-color:whitesmoke;position:static;" 
			method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<h2>Pick your the Date!</h2>
			<input type="date" style="font-size:25px;" name="rental_date"/>
			<div style="display:block;margin:0;">
			<input type="submit" name="pickdate"/>
			
<?php
if(isset($_POST['pickdate'])){
	$rental_date=$_POST['rental_date'];
		$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date, rentals.status, sounds.name 
					FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
					INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
					WHERE customers.cust_username= '$user' AND rentals.rental_date= '$rental_date'";
			$result = mysqli_query($mysqli, $query);
			
			$queryresults = mysqli_num_rows($result);
?>
<br>
			<br>
			<p style="font-size:30px;">Date picked...</p>
			<h4><?php echo $rental_date;?></h4>
		</form>
	</div>
		
	<?php 
	
			if ($queryresults !=0){
			$no=1;
			while ($row = mysqli_fetch_array($result)){
				echo '<form style="background-color:powderblue;" >
						
						<h3>'.$row['name'].'</h3>
						<p><b>Rental Date: </b>'.$row['rental_date'].'</p>
						<p><b>Return Date: </b>'.$row['return_date'].'</p>
						<p><b>Status: </b>'.$row['status'].'</p>
						
						</form>';
					$no++;
			}
			}else{
			echo '<p style="font-size:30px;">No Rental Activities...</p>';
			}
	
	}	
	?>
</div>	
</div>
