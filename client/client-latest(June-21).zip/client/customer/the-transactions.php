<div id="grad-bg">
	<br>
	<?php
	$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name 
				FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
				INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
				WHERE customers.cust_username= '$user' AND rentals.status= 'Pending'";
		
	$result = mysqli_query($mysqli, $query);
	if(!$result ) {
				die('Could not display data: ' . mysql_error()); //display errors 
	}
	?>
	<h3 class="text-center">Pending Transactions</h3>
	<br>
	<table class="table table-striped">
			<thead class="thead-dark">
				<tr>
					<th width="10%">Name of Package</th>
					<th width="10%">Rental Date</th>
					<th width="10%">Return Date</th>
					<th width="5%">Status</th>
				</tr>
			</thead>
			<tbody>
			<?php	//for the data will be displayed
				$no=1;
				while ($row = mysqli_fetch_array($result)){
				echo '<tr>
						<td >'.$row['name'].'</td>
						<td >'.$row['rental_date'].'</td>
						<td >'.$row['return_date'].'</td>
						<td>'.$row['status'].'</td>
					</tr>';
					$no++;
			}?>
			</tbody>
	</table>
	<div id="grad-bg">
	<br>
	<h3 class="text-center">Recent Transactions</h3>
	<br>
	<hr>
	<div>
	<?php
	$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date,rentals.status, sounds.name 
				FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
				INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
				WHERE customers.cust_username= '$user' AND rentals.status= 'Renting'";
		
	$result = mysqli_query($mysqli, $query);
	if(!$result ) {
				die('Could not display data: ' . mysql_error()); //display errors 
	}
	?>
	<h4>Renting</h4>
	<table class="table table-striped">
			<thead class="thead-dark">
				<tr>
					<th width="10%">Name of Package</th>
					<th width="10%">Rental Date</th>
					<th width="10%">Return Date</th>
					<th width="5%">Status</th>
				</tr>
			</thead>
			<tbody>
			<?php	//for the data will be displayed
				$no=1;
				while ($row = mysqli_fetch_array($result)){
				echo '<tr>
						<td >'.$row['name'].'</td>
						<td >'.$row['rental_date'].'</td>
						<td >'.$row['return_date'].'</td>
						<td>'.$row['status'].'</td>
					</tr>';
					$no++;
			}?>
			</tbody>
	</table>
	</div>
	<br>
	<hr>
	<div>
	<?php
	$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date,rentals.status, sounds.name 
				FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
				INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
				WHERE customers.cust_username= '$user' AND rentals.status= 'Rented'";
		
	$result = mysqli_query($mysqli, $query);
	if(!$result ) {
				die('Could not display data: ' . mysql_error()); //display errors 
	}
	?><h4>Rented</h4>
	<table class="table table-striped">
			<thead class="thead-dark">
				<tr>
					<th width="10%">Name of Package</th>
					<th width="10%">Rental Date</th>
					<th width="10%">Return Date</th>
					<th width="5%">Status</th>
				</tr>
			</thead>
			<tbody>
			<?php	//for the data will be displayed
				$no=1;
				while ($row = mysqli_fetch_array($result)){
				echo '<tr>
						<td >'.$row['name'].'</td>
						<td >'.$row['rental_date'].'</td>
						<td >'.$row['return_date'].'</td>
						<td>'.$row['status'].'</td>
					</tr>';
					$no++;
			}?>
			</tbody>
	</table>
	</div>
	<br>
	<hr>
	<div>
	<?php
	$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date, rentals.status, sounds.name 
				FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
				INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
				WHERE customers.cust_username= '$user' AND rentals.status= 'Cancelled'";
		
	$result = mysqli_query($mysqli, $query);
	if(!$result ) {
				die('Could not display data: ' . mysql_error()); //display errors 
	}
	?><h4>Cancelled</h4>
	<table class="table table-striped">
			<thead class="thead-dark">
				<tr>
					<th width="10%">Name of Package</th>
					<th width="10%">Rental Date</th>
					<th width="10%">Return Date</th>
					<th width="5%">Status</th>
				</tr>
			</thead>
			<tbody>
			<?php	//for the data will be displayed
				$no=1;
				while ($row = mysqli_fetch_array($result)){
				echo '<tr>
						<td >'.$row['name'].'</td>
						<td >'.$row['rental_date'].'</td>
						<td >'.$row['return_date'].'</td>
						<td>'.$row['status'].'</td>
					</tr>';
					$no++;
			}?>
			</tbody>
	</table>
	</div>
	</div>
	</div>
