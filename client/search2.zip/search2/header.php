<?php
include('db_connect.php');
?>

<html>
 <head>
        <title>search</title>
    <link rel="stylesheet" type="text/css" href="style.css"> 
</head>
</html>