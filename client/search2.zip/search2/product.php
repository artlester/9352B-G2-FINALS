<?php
    include('header.php');
?>
    <html>
    <body>
    
    <h1>Products</h1>
    
        <div class="results-container">
            <?php
            
                $title = mysqli_real_escape_string($conn, $_GET['title']);
                $category = mysqli_real_escape_string($conn, $_GET['category']);  
            
               $sql ="SELECT * FROM sounds s
                        JOIN
                    categorysound cs ON s.sound_id = cs.sound_id
                        JOIN
                    categories c ON c.category_id = cs.category_id
                    WHERE name = '$title' AND category = '$category'"; 
            
               $result=mysqli_query($conn,$sql);
               $queryResults=mysqli_num_rows($result);
                
                    if($queryResults > 0){
                        while($row = mysqli_fetch_assoc($result)){
                            echo"<div class='result-box'>
                            
                                    <h3>".$row['name']."</h3>
                                    <p>".$row['description']."</p>
                                    <p>".$row['duration']."</p>
                                    <p>".$row['date_availability']."</p>
                                    <p>".$row['status']."</p>
                                    
                                </div>";
                        } 
                    }
                ?>
            </div>
</body>
    </html>
    