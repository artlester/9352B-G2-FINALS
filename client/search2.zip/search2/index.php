<?php
    include('header.php');
?>
    <html>
    <body>
    <form action="search.php" method="POST">
            <input type="text" name="search" placeholder="Search...">
            <button type="submit" name="submit-search">Search</button> 
    </form>
</body>
    </html>
    