<?php
    include('header.php');
?>
    <html>
    <body>
    <form action="search.php" method="POST">
            <input type="text" name="search" placeholder="Search...">
            <button type="submit" name="submit-search">Search</button> 
    </form>
    <h1>Products</h1>
    
        <div class="results-container">
            <?php
               $sql ="SELECT * FROM sounds"; 
               $result=mysqli_query($conn,$sql);
               $queryResults=mysqli_num_rows($result);
                
                    if($queryResults > 0){
                        while($row = mysqli_fetch_assoc($result)){
                            echo"<div class='result-box'>
                                    <h3>".$row['name']."</h3>
                                    <p>".$row['description']."</p>
                                    <p>".$row['duration']."</p>
                                    <p>".$row['date_availability']."</p>
                                    <p>".$row['status']."</p>
                                </div>";
                        } 
                    }
                ?>
            </div>
</body>
    </html>
    