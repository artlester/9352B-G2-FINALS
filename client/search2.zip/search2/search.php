<?php
include('header.php');
?>


<h1>Search Results:</h1>

<div class="results-container">
     
    <?php
    
        if(isset($_POST['submit-search'])){
            
            $search = mysqli_real_escape_string($conn, $_POST['search']);
            $sql = "SELECT *
                FROM
                    sounds s
                        JOIN
                    categorysound cs ON s.sound_id = cs.sound_id
                        JOIN
                    categories c ON c.category_id = cs.category_id
                where c.category LIKE '%$search%' OR s.name LIKE '%$search%'
                ORDER BY s.status";
            
            $result = mysqli_query($conn, $sql);
            $queryResults = mysqli_num_rows($result);
            
            echo "There are " .$queryResults. " results!";
            
            if($queryResults >0){
                while ($row = mysqli_fetch_assoc($result)){
                    echo "<div class='result-box'>
                                    <h3>".$row['name']."</h3>
                                    <p>".$row['description']."</p>
                                    <p>".$row['duration']."</p>
                                    <p>".$row['date_availability']."</p>
                                    <p>".$row['status']."</p>
                                </div>";
                } 
            }else{
                echo " There are no results matching your search!";
            }
        }
    ?>

</div>
 
