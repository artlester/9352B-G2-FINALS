<?php

$server="localhost";
$username="root";
$password="";


$dbname="audirentur";

$conn =mysqli_connect($server,$username, $password, $dbname);

?>