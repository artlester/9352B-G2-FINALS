<?php
if(isset($_POST['update'])) {
            require('db.php');
            require ('session.php');
            
			$cust_sql=("SELECT cust_id from customers where cust_username='$user'");
			
			$rental_id = $_POST['rental_id'];
            $rental_date = $_POST['rental_date'];
			$return_date = $_POST['return_date'];
            
            $mysql = "INSERT INTO rentals (rental_id, rental_date, return_date, cust_id)
			VALUES ($rental_id, $rental_date, $return_date, $cust_sql)";
            
            if(!$retval ) {
               die('Could not update data: ' . mysql_error());
            }
            echo "Updated data successfully\n";
            
            mysqli_close($conn);
         }else {
?>
<form action="rent.php" method="post">
		Name: <input type="text" name="name"><br>
		Enter Rental Date: <input type="text" name="YYYY/MM/DD"><br>
		Enter Return Date: <input type="text" name="YYYY/MM/DD"><br>
		<input type="submit">
</form>