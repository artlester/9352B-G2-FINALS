
<?php
require ('db.php');

$itemCount = 0;

if(isset($_SESSION['cart'])){
   
   $itemCount = count(isset($_SESSION['cart']) ? $_SESSION['cart'] : array());

}
?>
<body>
    <nav>
			<div>
				<text><?php echo'<h6>Added items in cart:'.'[' . $itemCount . ']</h6>';?></text>
				<button><a href="profile.php">View Cart</a></button>
			</div>

    </nav>


	<div class="container main-cude">


        <p class="msg">

        <?php if(isset($_REQUEST['msg'])){

			switch($_REQUEST['msg']):

			case 'add':

				$msg = $_REQUEST['p'] . " was added to your cart.";

            break;

            case 'exists':

				$msg = $_GET['p'] . " already in your cart.";

            break;

            endswitch;

            echo $msg;

            }

        ?>

        </p>

    <h4>Products in shop</h4>
	

    <div class="clear"></div>

        <?php

			$query = "SELECT * FROM  `sounds` ";
			$result= mysqli_query($mysqli,$query);
                while($row= mysqli_fetch_array($result)){
                extract($row);
        ?>
   
    <div>
		<form style="width:200px;float:left;padding:10px;">
			<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px; " align="center">
				<img src="images/<?php echo $row["img"]; ?>" class="img-responsive" /><br />
				<h4><?php echo $row["name"]; ?></h4>
				<h4>Php <?php echo $row["price"]; ?></h4>
				<td><a href="curd.php?action=add&pid=<?=$sound_id?>&p=<?=$name?>" class="button-cart">Add to Cart</a></td>
			</div>
		</form>
    </div>

    <?php }?>

    <div class="clear"></div>
	

</div>
</body>
</html>