
<?php
  require('profile.php');
  //session_start();

	if(!isset($_REQUEST['pid'])){
		exit();
    }
    $pid = $_REQUEST['pid'];
	$pname = $_REQUEST['p'];
	$case = $_REQUEST['action'];
    
	// Check if session varible is set or not
	
	if(!isset($_SESSION['cart'])){

        $_SESSION['cart'] = array();

        }

    switch($case):

    case 'add':

		// Now check if product is already stored in session variable

		if(in_array($pid, $_SESSION['cart'])){
		// redirect to product list and tell the user it was added to cart
			echo '<script>alert("The item was already added to cart.");</script>';
		//header('Location: items.php?msg=exists&id=' . $pid . '&p=' . $pname);

    }

    else{

        if(!preg_match('/^[0-9]{1,}$/i', $pid)){//pattern match
			
            echo '<script>alert("Failed to add.");</script>';
			//header('Location: items.php?msg=exists&id' . $pid . '&p=' . $pname);

        }else{
			
            array_push($_SESSION['cart'], $pid);        

				// redirect to product list and tell user it was added to cart
			echo '<script>alert("The item is added to your cart.");</script>';
				//header('Location: items.php?msg=add&id' . $pid . '&p=' . $pname);

            }

        }
    break;

	case 'remove':

		if(!preg_match('/^[0-9]{1,}$/i', $pid)){
			
			echo '<script>alert("Failed to removed from cart.");</script>';
			//header('Location: items.php?msg=exists&id' . $pid . '&p=' . $pname);

			}else{

				 $_SESSION['cart'] = array_diff($_SESSION['cart'], array($pid));

				   // redirect to product list and tell the user it was removed from cart

					echo '<script>alert("The item will be remove from your cart.");</script>';
					//header('Location: cart.php?msg=removed&id=' . $sound_id . '&p=' . $pname);
			}
	break;
	case 'update':
?>
	<form action="rent.php" method="post">
		Name: <input type="text" name="name"><br>
		Enter Rental Date: <input type="text" name="YYYY/MM/DD"><br>
		Enter Return Date: <input type="text" name="YYYY/MM/DD"><br>
		<input type="submit">
	</form>
<?php
break;
endswitch;
?>