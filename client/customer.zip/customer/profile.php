<?php
	require 'db.php';
	include 'session.php' ;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Homepage</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/homepage.css">
    <!--link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/userbar.css"-->
</head>
<body>
<?php include 'userbar.php'; ?>
<div class="welcome text-center" id="welcome">
    <br>
    <h1 id="logo">Audirentur</h1>
    <h3 id="logo">The online rental for sound systems at the best and affordable price!</h3>
</div>
<div class="container">
	<div>
	<?php require('cart.php'); ?>
	</div>	
</div>	
<div class="container">
<div>
		<?php require('transactions.php'); ?>
	</div>	
	</div>

    <!--JAVASCRIPT-->
	
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>
</html>