<?php 
//require ('db.php');
//include ('session.php');
	$itemCount = 0;
    if(isset($_SESSION['cart'])){
        $itemCount = count(isset($_SESSION['cart']) ? $_SESSION['cart'] : array());
        }
?>
			<div class="container main-cude">
				<p class="msg">
				<?php if(isset($_REQUEST['msg'])){
					$msg ="";
					switch($_REQUEST['msg']):
					case 'add':
						$msg = '<b>'.$_REQUEST['p'] . "</b> was added to your cart.";
						break;
					case 'exists':
						$msg = '<b>'.$_GET['p'] . "</b> already in your cart.";
						break;
                    case 'removed':
						$msg = '<b>'.$_GET['p'] . "</b> was removed from your cart.";
                    break;
                    endswitch;
                    echo $msg;
                     }
                ?>
            </p>
    <?php
	
    // If cart is empty and user click on cart button show default product list
    if($itemCount == 0){
		echo '<b>Your Cart is empty!.';
	}
		/*echo ' Add items to it. </b>';
    ?>

    <?php
    $query = "SELECT * FROM  sounds ";
    $result = mysqli_query($mysqli,$query);
		while($row = mysqli_fetch_array($result)){
			extract($row);
			
    ?>
    <div>
		<div class="inline-pr"><?=$name?></div>
		<div class="inline-pr"><?=$price?></div>
		<div class="inline-pr">
			<a href="curd.php?action=add&pid=<?=$sound_id?>&p=<?=$name?>" class="button-cart">Add to Cart</a>
		</div>
    </div>

    <?php 
		}
    }*/
    // If user add product to its cart
    else{?>

        <h4><center>Products in your CART</center></h4>

        <?php
			$pids = "";
			foreach($_SESSION['cart'] as $sound_id){
			$pids = $pids. $sound_id.',';
            }
                        $pids = rtrim($pids, ",");

						$query = "SELECT sound_id, name, price FROM sounds WHERE sound_id IN (".$pids.")";

						$result = mysqli_query($mysqli,$query);

						$row = mysqli_num_rows($result);  // Count num of rows

						if($row == 0){

					         echo '<p class="msg">No products found in your cart.</p>';

						}else{

                        ?>

		<div class="clear"></div>
		<style>
			table{
			width:60%;
			margin:auto;
		}
	
	table td {
			transition: all .5s;
		}

		/* Table */
		.data-table {
			margin-top:20px;
			border-collapse: collapse;
			font-size: 14px;
			min-width: 537px;
			text-align:center;
		}

		.data-table th, 
		.data-table td {
			border: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.data-table caption {
			margin: 7px;
		}

		/* Table Header */
		.data-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}

		/* Table Body */
		.data-table tbody td {
			color: #353535;
		}
		.data-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.data-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
		}
		</style>
		<table class="data-table">
				<thead>
				<tr>
					<th width="40%">Item Name</th>
					<th width="20%">Price</th>
					<th width="10%" colspan="3"><center>Actions</center></th>
				</tr>
				</thead>
				</tbody>
        <?php
			while($rows = mysqli_fetch_array($result)){
			extract($rows);
        ?>
				<tr>
					<td><?=$name?></td>
					<td>Php <?=$price?></td>
						<td><a href="curd.php?action=remove&pid=<?=$sound_id?>&p=<?=$name?>" class="button-cart red-bt">Remove</a></td>
						<td><a href="curd.php?action=update&pid=<?=$sound_id?>&p=<?=$name?>" class="button-cart red-bt">Rent</a></td>
				</tr>
         
        <?php 
			}
			}
		} 
		?>
		</tbody>
</table>

    <div class="clear"></div>


</div>