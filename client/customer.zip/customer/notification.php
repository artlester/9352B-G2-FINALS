<?php
	require('db.php');
	
	function notification(){
		require('session.php');
		$query= "SELECT status, name FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
					INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
					WHERE customers.cust_username= '$user' ";
		$result = mysqli_query($mysqli, $query);

		if(!$result ) {
					die('Could not display data: ' . mysql_error()); //display errors 
		}
		while($row=mysqli_fetch_array($result)){
			echo  "Updates". $row['cust_username'] . $row['status']; 
		}
	}
?>