<?php  
require ('session.php');
require ('db.php');  
?>
<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/edit_profile.css">
<html>
   
   <head>
      
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Change Password</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/userbar.css">
   </head>
   
   <body style="margin:0; background: 	#D3D3D3;">
       
	   <div style=" border: 1px solid black; width: 450px; position:relative; margin: 0 auto; padding: 15px; margin-top: 100px; box-shadow: 0 0 20px #000;">
       <p style="font-size:50px; text-align:center;">Change Password</p>
       
            <form method = "post" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-style-9" >
               
                <input name = "old_pass" type = "password" id = "old_pass" placeholder="Old Password" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
                <br>
                <input name = "new_pass" type = "text" id = "new_pass" placeholder="New Password" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
             
                <br>
                <input name = "retype_pass" type = "text" id = "retype_pass" placeholder="Re-type Password" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
                     
               <br>
                <br>
                <table>
                <tr>
                    
        <td><a href="http://customer.audirentur.com/profile.php" style="background-color: red;
                    color: white;
                    padding: 14px 20px;
                    margin: 0 auto;
                    margin-top:20px;
                    float:left;
                    position:relative;  
                    display:block;
                    cursor: pointer;
                    width: 200px;
                    text-align:center;
                 opacity: 0.9;  ">Cancel</a></td>
        <td><button name="update" type="text" value="SUBMIT" style="background-color: #4CAF50;
                    color: white;
                    padding: 14px 20px;
                    margin: 0 auto;
                    margin-top:20px;
                    margin-left:20px;
                    position:relative;  
                    display:block;
                    cursor: pointer;
                    width: 200px;
        opacity: 0.9;  ">Update</button></td></tr></table>
        
     </form>
    </div>
         <?php
       if($_SESSION['username']){
         if(isset($_POST['update'])) {
               
             $cust_id = $_SESSION['customer_id'];
             $newusername = $_SESSION['username'];
             $typed_password = ($_POST['old_pass']);
             $newpassword = ($_POST['new_pass']);
             $retype_password = ($_POST['retype_pass']);

            
               
            // Attempt update query execution
            /*$query = "UPDATE customers ". "SET cust_password = '$newpassword'". 
               "WHERE customer_id = $cust_id" ;*/
             $result = $mysqli->query("SELECT cust_password FROM customers WHERE customer_id = $cust_id");
             $row = $result->fetch_assoc();
             
             
                ob_start();
                echo ($row['cust_password']);
                $oldpassworddb = ob_get_contents(); 
                ob_end_clean();

             //echo "$oldpassworddb/$typed_password";
             
             if($oldpassworddb==$typed_password){
                 if($newpassword==$retype_password){
                     
                $query = "UPDATE customers ". "SET cust_password = '$newpassword'". 
                         "WHERE customer_id = $cust_id" ;
                     
                    if(mysqli_query($mysqli, $query)){
                        $url = "http://customer.audirentur.com/index.php";
                        $messageok = 'Password successfully changed!';
                        echo "<script type='text/javascript'>alert('$messageok');</script>";
                        echo '<script>window.location = "'.$url.'";</script>';
                        session_destroy(); 
                        mysqli_close($mysqli);
                    } else {
                        echo "ERROR: Could not able to execute $query. " . mysqli_error($mysqli);
                    }
                     
                 }else{
                     $notMatch = 'New password does not match!';
                        echo "<script type='text/javascript'>alert('$notMatch');</script>";
                     $url = "http://customer.audirentur.com/change_password.php";
                    echo '<script>window.location = "'.$url.'";</script>';
                 }
                 
             }else{
                 $notMatch2 = 'Old password does not match!';
                        echo "<script type='text/javascript'>alert('$notMatch2');</script>";
                     $url = "http://customer.audirentur.com/change_password.php";
                    echo '<script>window.location = "'.$url.'";</script>';
             }
         }
             
            
       }
      ?>
     
   </body>
</html>