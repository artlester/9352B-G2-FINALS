<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: View</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" media="screen" href="http://audirentur.com/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="http://audirentur.com/css/fontawesome-all.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="http://audirentur.com/css/index.css" />
</head>
<body style="background-color:#e3e3e3;padding-bottom:50px;margin-bottom:30%;">
    <div class="container-fluid bg-black" id="bg-black">
        <div>
            <nav class="nav nav-pills nav-fill">
                <h1><a class="nav-item nav-link text-light" href="http://audirentur.com/index.html"><i class="fas fa-home" style="margin-right:5px;"></i>Home</a></h1>
                <h1><a class="nav-item nav-link text-light" href="http://customer.audirentur.com"><i class="fas fa-sign-in-alt" style="margin-right:5px;"></i> Log In</a></h1>
            </nav>
        </div>
    </div>
    <br>
	<div> 
<?php
require 'db.php';

$mysqli = new mysqli(hostname,user,password,mysql_database) or die($mysqli->error);
if(isset($_GET['sound_id'])){
	$sound_id=$_GET['sound_id'];
	
			$query = "SELECT * FROM sounds NATURAL JOIN vendors WHERE sounds.sound_id='$sound_id'";
            $result = mysqli_query($mysqli, $query);
	
        while ($row = mysqli_fetch_assoc($result)){
			$availability=date_create($row['date_availability']);
			?>
	<div style="width:40%;height:500px;float:left;text-align:center;background:white;margin:0 40px; padding: 40px 10px 10px 10px;" class="prod-img">
		<img src="http://audirentur.service.com:3000/uploads/<?php echo $row['product_image']?>" 
		style="width:25vw;overflow:auto;vertical-align:center;"/>
		</div>
		<div style="width:50%;height:auto;float:left;">
		<div style="width:100%;height:50%;float:left;padding: 30px;font-family:Roboto;border:1px groove;" class="info-div">

			<h3><b><?php echo $row['name']; ?></b></h3>
			<ul style="list-style:none; font-size: 25px;">
			<li><b>Price:</b>&nbsp;Php&nbsp;<?php echo $row['price']?>.00</li>
			<li><b>Available:</b>&nbsp;<?php echo date_format($availability,"F d, Y");?></li>
			<li><b>Status:&nbsp;</b><b><?php echo strtoupper($row['status']); ?></b></li>
			<hr>
			<li><b>Description:</b>&nbsp;<p style="font-size:20px;text-align:left;margin-right:30px;"><?php echo $row['description']?><p></li>
			</ul>
			<a href="http://customer.audirentur.com"><button class="btn btn-primary" style="padding:2px 65px 2px 65px;width:100%;">
			Rent</button></a>
        </div>
<?php			
		}  
}
?>
</div>
	
    <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>