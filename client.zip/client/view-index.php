<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: View</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" media="screen" href="http://audirentur.com/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="http://audirentur.com/css/fontawesome-all.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="http://audirentur.com/css/index.css" />
</head>
<body>
    <div class="container-fluid bg-black" id="bg-black">
        <div>
            <nav class="nav nav-pills nav-fill">
                <h1><a class="nav-item nav-link text-light" href="http://audirentur.com/index.html"><i class="fas fa-home"></i>Home</a></h1>
                <h1><a class="nav-item nav-link text-light" href="http://customer.audirentur.com"><i class="fas fa-sign-in-alt"></i> Log In</a></h1>
            </nav>
        </div>
    </div>
    <br>
	<div> 
<?php
define("hostname",'127.0.0.1');
define("user",'root');
define("password",'');
define("mysql_database",'audirentur');

$mysqli = new mysqli(hostname,user,password,mysql_database) or die($mysqli->error);
$sound_id=$_POST['sound_id'];
if(isset($_POST['view-details'])){
	
			$query = "SELECT * FROM sounds NATURAL JOIN vendors WHERE sounds.sound_id='$sound_id'";
            $result = mysqli_query($mysqli, $query);
	
        while ($row = mysqli_fetch_assoc($result)){
			?>
		<div style="width:50%;float:left;text-align:center;">
		<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $row['product_image']).'" style="width:30vw;height:auto;"/>'?>
		</div>
		<form action="./customer/rent.php" method="post">
		<div style="width:50%;float:left;padding-bottom:100px;">
			<h1 class="text-info"><?php echo $row['name']; ?></h1>
			<h2 class="text-info">Duration:&nbsp;<?php echo $row['duration']; ?>&nbsp;days</h2>
			<h2 class="text-danger">Price:&nbsp;Php&nbsp;<?php echo $row['price']?>.00</h2>
            <h2 class="text-danger">Available:&nbsp;<?php echo $row['date_availability'];?></h2>
            <h2 class="text-danger">Status:&nbsp;<i><?php echo strtoupper($row['status']); ?></i></h2> 
			<p style="font-size:20px;">Description:&nbsp;<?php echo $row['description']?><p>
			<h1 class="text-info">Vendor name:&nbsp;<?php echo $row['ven_username']?></h1>
			<h3 class="text-info">Contact:&nbsp;<?php echo $row['ven_contact_number']?></h3>
			<input name="sound_id" type="hidden" value="<?php echo $row['sound_id'];?>"></input>
			<input type="submit" name="rent" value="RENT" class="btn btn-primary" style="padding:6px 30px 6px 30px;" ></input>
        </div>
		</form>
<?php			
		}  
}
?>
</div>
	
    <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>