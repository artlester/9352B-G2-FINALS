SETTING UP THE CUSTOMER MODULE
	Step 1. Open Wampserver, you will notice a new icon in your system tray.Wait until the icon turns green.
	Step 2. Click the icon and choose 'Apache' then open 'httpd-vhosts.conf' and edit/insert the following codes:
			<VirtualHost *:80>
		  		ServerName audirentur.com  //the domain name for the website created
		  		ServerAlias www.audirentur.com  //the alternative domain name 
		  		DocumentRoot "${INSTALL_DIR}/www/client"  //the directory of the WAMP server
		  		<Directory "${INSTALL_DIR}/www/client/">
					Options +Indexes +Includes +FollowSymLinks +MultiViews
					AllowOverride All
		  		</Directory>
			</VirtualHost>
			<VirtualHost *:80>
		  		ServerName customer.audirentur.com
		  		ServerAlias www.customer.audirentur.com
		  		DocumentRoot "${INSTALL_DIR}/www/client/customer"
			</VirtualHost>

	Step 3. After inserting the following code, save the file by clicking the 'File' and click 'Save' or press 'Ctrl + S' keys.Then exit the editor.
	step 4. Then restart Apache Service by clicking 'Restart All Services'.Wait until the icon turns green.
	sTEP 5. To know your ip address for the website, click 'Start' then in 'Search programs and files' box, type "cmd" and When the command prompt window appears, type in �ipconfig� and press 'Enter'.
	Step 6. Then, go to 'C:\WINDOWS\System32\drivers\etc' choose the 'hosts' file, right click and click on 'Edit with Notepad++'.
		Insert the ip addresses and the domain name for the website:
		*IP address* audirentur.com
		*IP address* customer.audirentur.com

		Add the ip address and the domain name for the service provider website and the database.
		*IP address* audirenture.service.com
		*IP address* db.com

	Step 7. Save the 'host' file and when an informational message informing you that you are editing a locked/protected file click 'Yes' then save the file or press 'ctrl + S'.
		Exit the Notepad++.

