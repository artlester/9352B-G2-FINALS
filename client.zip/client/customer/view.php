<?php require 'db.php';require 'session.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: View</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
	<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fonts.css">
</head>
<body style="background-color:#e3e3e3">
    <?php include 'userbar.php' ?>
    <div style="background:url(./img/heading.jpeg)">
		<center>
		<?php include 'advertisement.html';?>
		</center>
    </div>
    <div class="container-fluid bg-black" id="bg-black">
        <div class="container">
            <nav class="nav nav-pills nav-fill">
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=speaker"><h3>Speakers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=equalizer"><h3>Equalizers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=amplifier"><h3>Amplifiers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=bundle"><h3>Bundles</h3></a>
				<h3 class="nav-item" style="width:350px;float:left;padding;"><?php include'miniSearchBar.html';?></h3>
			</nav>
        </div>
    </div>
    <br>
	<div>
<?php
$sound_id=$_POST['sound_id'];

if(isset($_POST['view-details'])){
			$query = "SELECT * FROM sounds NATURAL JOIN vendors WHERE sounds.sound_id='$sound_id'";
			
            $result = mysqli_query($mysqli, $query);
        while ($row = mysqli_fetch_assoc($result)){
			$_SESSION['sound_id']=$row['sound_id'];
			?> 			
		<div style="width:40%;float:left;text-align:center;background:white;margin:0 40px;">
		<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $row['product_image']).'" 
		style="width:25vw;overflow:auto;vertical-align:center;"/>'?>
		</div>
		<div style="width:50%;float:left;padding-bottom:70px;padding-left:20px;font-family:RenaultBQ-Light;border:1px groove;">
		<form action="http://customer.audirentur.com/rent.php" method="post">
			<h1><?php echo $row['name']; ?></h1>
			<h2>Duration:&nbsp;<?php echo $row['duration']; ?>&nbsp;days</h2>
			<h2 >Price:&nbsp;Php&nbsp;<?php echo $row['price']?>.00</h2>
            <h2 >Available:&nbsp;<?php echo $row['date_availability'];?></h2>
            <h2>Status:&nbsp;<i><?php echo strtoupper($row['status']); ?></i></h2> 
			<p style="font-size:20px;"><b>Description:</b>&nbsp;<?php echo $row['description']?><p>
			<input name="sound_id" type="hidden" value="<?php echo $row['sound_id'];?>"/>
			<input type="submit" name="rent" value="RENT" class="btn btn-primary" style="padding:6px 30px 6px 30px;"/>
        </form>
		<form action="http://customer.audirentur.com/vendor.php" method="post">
			<h1>Vendor name:&nbsp;<?php echo $row['ven_username']?></h1>
			<h3>Contact:&nbsp;<?php echo $row['ven_contact_number']?></h3>
			<input name="vendor_id" type="hidden" value="<?php echo $row['vendor_id'];?>"/>
			<input type="submit" name="view" value="View Profile" class="btn btn-primary" style="padding:6px 30px 6px 30px;"/>
			</form>
		</div>
<?php			
		}
}
?>
</div>
</div>


	
    <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>