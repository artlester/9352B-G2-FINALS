<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/homepage-1.css">
<?php
    $category = $_GET['category'];
    switch ($category) {
            
         case "speaker": 
            
        $sql ="SELECT 
                        *
                    FROM
                        sounds s
                            LEFT JOIN
                        categories c ON c.category_id = s.category_id
                    WHERE
                         c.category = 'speaker'
                    ORDER BY s.price";
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
            echo "<h1>SPEAKERS</h1>";
             if($queryResults >0){
                while ($product = mysqli_fetch_array($result)){
                    ?>
            <div class="card-body card-hover" style="width:400px;float:left;text-align:center;height:550px;">
				<form action="http://customer.audirentur.com/view.php" method="post">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);padding:3% 1%;">
						<div class="card-img-top">
							<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $product['product_image']).'" style="width:210px;height:200px;"/>'?>
						</div>
						<h4 class="card-title"><?php echo $product["name"]; ?></h4><br>
						<h4 class="card-subtitle">Duration:&nbsp;<?php echo $product['duration']; ?>&nbsp;days</h4><br>
						<h5 class="card-subtitle">Available:&nbsp;<?php echo $product['date_availability'];?></h5><br>
						<h6 class="card-subtitle">Status:&nbsp;<i><?php echo strtoupper($product['status']); ?></i></h6><br>
						<h5 class="card-subtitle">Price: PHP <?php echo $product['price'];?></h5><br>
						<input name="sound_id" type="hidden" value="<?php echo $product['sound_id'];?>"/>
						<input type="submit" name="view-details" value="VIEW" class="btn btn-primary" style="padding:2px 65px 2px 65px"/>
                    </div>
				</form>
				</div>
            
            <?php
				}  
                }else{
                echo " There are no results matching your search!";
            }  
            
            break; 
            
            
            
        case "amplifier": 
            $sql ="SELECT 
                        *
                    FROM
                        sounds s
                            LEFT JOIN
                        categories c ON c.category_id = s.category_id
                    WHERE
                         c.category = 'amplifier'
                    ORDER BY s.price"; 
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
            echo "<h1>AMPLIFIERS</h1>";
             if($queryResults >0){
                while ($product = mysqli_fetch_array($result)){
                    ?>
            <div class="card-body card-hover" style="width:400px;float:left;text-align:center;height:550px;">
				<form action="http://customer.audirentur.com/view.php" method="post">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);padding:3% 1%;">
						<div class="card-img-top">
							<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $product['product_image']).'" style="width:210px;height:200px;"/>'?>
						</div>
						<h4 class="card-title"><?php echo $product["name"]; ?></h4><br>
						<h4 class="card-subtitle">Duration:&nbsp;<?php echo $product['duration']; ?>&nbsp;days</h4><br>
						<h5 class="card-subtitle">Available:&nbsp;<?php echo $product['date_availability'];?></h5><br>
						<h6 class="card-subtitle">Status:&nbsp;<i><?php echo strtoupper($product['status']); ?></i></h6><br>
						<h5 class="card-subtitle">Price: PHP <?php echo $product['price'];?></h5><br>
						<input name="sound_id" type="hidden" value="<?php echo $product['sound_id'];?>"/>
						<input type="submit" name="view-details" value="VIEW" class="btn btn-primary" style="padding:2px 65px 2px 65px"/>
                    </div>
				</form>
				</div>
            <?php
                                
                }  
                }else{
                echo " There are no results matching your search!";
            }  
            
            break;
            
            
            
        case "bundle": 
		
            $sql ="SELECT 
                        *
                    FROM
                        sounds s
                            LEFT JOIN
                        categories c ON c.category_id = s.category_id
                    WHERE
                         c.category = 'bundle'
                    ORDER BY s.price"; 
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
            echo "<h1>BUNDLES</h1>";
            if($queryResults >0){
               while ($product = mysqli_fetch_array($result)){
                    ?>
            <div class="card-body card-hover" style="width:400px;float:left;text-align:center;height:550px;">
				<form action="http://customer.audirentur.com/view.php" method="post">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);padding:3% 1%;">
						<div class="card-img-top">
							<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $product['product_image']).'" style="width:210px;height:200px;"/>'?>
						</div>
						<h4 class="card-title"><?php echo $product["name"]; ?></h4><br>
						<h4 class="card-subtitle">Duration:&nbsp;<?php echo $product['duration']; ?>&nbsp;days</h4><br>
						<h5 class="card-subtitle">Available:&nbsp;<?php echo $product['date_availability'];?></h5><br>
						<h6 class="card-subtitle">Status:&nbsp;<i><?php echo strtoupper($product['status']); ?></i></h6><br>
						<h5 class="card-subtitle">Price: PHP <?php echo $product['price'];?></h5><br>
						<input name="sound_id" type="hidden" value="<?php echo $product['sound_id'];?>"/>
						<input type="submit" name="view-details" value="VIEW" class="btn btn-primary" style="padding:2px 65px 2px 65px"/>
                    </div>
				</form>
				</div>
            <?php
                                
                }  
                }else{
                echo " There are no results matching your search!";
            }  
            
            break; 
            
            
            
        case "equalizer": 
            
            $sql ="SELECT 
                        *
                    FROM
                        sounds s
                            LEFT JOIN
                        categories c ON c.category_id = s.category_id
                    WHERE
                         c.category = 'equalizer'
                    ORDER BY s.price";  
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
            echo "<h1>EQUALIZERS</h1>";
            if($queryResults >0){
               while ($product = mysqli_fetch_array($result)){
                    ?>
            <div class="card-body card-hover" style="width:400px;float:left;text-align:center;height:550px;">
				<form action="http://customer.audirentur.com/view.php" method="post">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);padding:3% 1%;">
						<div class="card-img-top">
							<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $product['product_image']).'" style="width:210px;height:200px;"/>'?>
						</div>
						<h4 class="card-title"><?php echo $product["name"]; ?></h4><br>
						<h4 class="card-subtitle">Duration:&nbsp;<?php echo $product['duration']; ?>&nbsp;days</h4><br>
						<h5 class="card-subtitle">Available:&nbsp;<?php echo $product['date_availability'];?></h5><br>
						<h6 class="card-subtitle">Status:&nbsp;<i><?php echo strtoupper($product['status']); ?></i></h6><br>
						<h5 class="card-subtitle">Price: PHP <?php echo $product['price'];?></h5><br>
						<input name="sound_id" type="hidden" value="<?php echo $product['sound_id'];?>"/>
						<input type="submit" name="view-details" value="VIEW" class="btn btn-primary" style="padding:2px 65px 2px 65px"/>
                    </div>
				</form>
				</div>
            <?php
                                
                }  
                }else{
                echo " There are no results matching your search!";
            }  
            
            break; 
            
            
        default: echo "None";
    }
?>