<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.button{
	margin-left:10%;
	margin-top: 1%;
	padding:0 40px;
	background-color:#5cb85c;
	color:white;
	font-size:30px;
	border-radius: 2px;
}
.button:hover {
	background-color:#592EC8E;
	color:white;
}
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
/* Modal Header */
.modal-header {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}

/* Modal Body */
.modal-body {
	padding: 2px 16px;
	font-size:20px;
	}

/* Modal Footer */
.modal-footer {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}

/* Modal Content */
.modal-content {
    position: relative;
    background-color: #fefefe;
    margin:0 auto;
    padding: 0;
    border: 1px solid #888;
    width: 50%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    animation-name: animatetop;
    animation-duration: 0.4s;
	text-align:center;
}

/* Add Animation */
@keyframes animatetop {
    from {top: -300px; opacity: 0}
    to {top: 0; opacity: 1}
}

</style>
</head>
<body>

<button id="myBtn" class="button">Rentals</button>

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
	<div class="modal-header">
	<h2>Rentals on this package</h2>
	<span class="close" style="text-align:right;">&times;</span>
	</div>
	<div class="modal-body">
	<table width="50%">
		<tr>
			<th width="10%">Rental Date</th>
			<th width="10%">Return Date</th>
			<th width="10%">Status</th>
		</tr>
		</table>
	<?php
	$sound_id=$_GET['id'];
	$query="SELECT rentals.rental_date, rentals.return_date , 
	rentals.status FROM sounds INNER JOIN rentals ON sounds.sound_id=rentals.sound_id WHERE sounds.sound_id='$sound_id'";
	$result = mysqli_query($mysqli, $query);
		if(empty($result)){
			echo 'No Rental events';
		}else{
        while ($row = mysqli_fetch_assoc($result)){
			$rental=date_create($row['rental_date']);
			$return=date_create($row['return_date']);
		
	?>
		<table width="50%">
		<tr>
			<td width="10%"><?php echo date_format($rental,"F d,Y");?></td>
			<td width="10%"><?php echo date_format($return,"F d,Y");?></td>
			<td width="10%"><?php echo $row['status']?></td>
		</tr>
		</table>
	</table>
		<?php }}?>
  </div>
	<div>
	 <div class="modal-footer">
		<h6>© Copyright 2018 Audirentur</h6>
	  </div>
	</div>
</div>

<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</body>
</html>
