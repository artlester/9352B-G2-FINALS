<?php include 'session.php'; include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/profile.css">
</head>
<style>
	.settings h4 {
		font-size: 17px;
	}
	.settings a {
		color: #696C6F;
		text-decoration: none;
		transition: 1s;
	}
	
</style>
<body>
    <?php include 'userbar.php' ?>
	
    <div class="container" id="profile" style="min-height:100%;height:auto;max-height:none;background-color:#E2ECE2;">
		<div style="background-color:#F5F5F5;left:0;right:0;margin:0 -15px 0 -15px;position:relative;padding-top:20px;box-shadow:1px 1px 5px 1px rgba(56, 59, 61, 0.3);">
		<table style="text-align:center;width:100%;left:0;right:0;margin:0;" class="settings"><tr>	
			<td width="33%"><a href="http://customer.audirentur.com/edit_profile.php"><h4><i class="fa fa-pencil-alt" style="margin-right: 10px;"></i>Edit Profile</h4></a></td>
			<td width="33%"><a href="http://customer.audirentur.com/change_password.php"><h4><i class="fa fa-pencil-alt" style="margin-right: 10px;"></i>Change Password</h4></a></td>
			<td width="33%"><a href="http://customer.audirentur.com/change_picture.php"><h4><i class="fa fa-pencil-alt" style="margin-right: 10px;"></i>Change Profile Picture</h4></a></td>
        </tr></table></div>
		<br>
        <div class="text-center text-dark">
            <?php
			$query="SELECT * FROM customers WHERE cust_username='$user'";
			$result=mysqli_query($mysqli,$query);
			while($row = mysqli_fetch_array($result)){
                if(empty($row['cust_avatar'])) {
                    if($row['cust_gender'] == "Male") {
                        echo '<img src="img/default_avatar_male.jpg" id="profile-picture" width="270px" height="270px">';
                    } else {
                        echo '<img src="img/default_avatar_female.jpg" id="profile-picture" width="270px" height="270px">';
                    }
                } else {
				echo '<img src="data:img/jpg;base64,'.base64_encode( $row['cust_avatar']).'" style="width:270px;height:270px;"/>';
                }
                echo '<h1>'. $row['cust_first_name'] . ' ' . $row['cust_last_name'] .'</h1>';
                echo '<h4>@' . $row['cust_username'] . '</h4>';
			}
            ?>
		</div>
        <div class="text-dark">
            <h3><i class="fa fa-id-card"></i> Bio</h3>
            <?php
			$query="SELECT * FROM customers WHERE cust_username='$user'";
			$result=mysqli_query($mysqli,$query);
			while($row = mysqli_fetch_array($result)){
                if($row['cust_bio'] === NULL) {
                    echo '<h5> &nbsp; &nbsp; &nbsp; This user is too lazy to add a bio.</h5>';
                } else {
                    echo '<h5> &nbsp; &nbsp; &nbsp; ' . $row['cust_bio'] . '</h5>';
                }
            ?>
            <br>
            <h3><i class="fa fa-venus-mars"></i> Gender</h3>
            <?php echo '<h5> &nbsp; &nbsp; &nbsp ' . $row['cust_gender'] . '</h5>'; ?>
            <br>
            <h3><i class="fa fa-phone"></i> Contact Number</h3>
            <?php echo '<h5> &nbsp; &nbsp; &nbsp ' . $row['cust_contact_number'] . '</h5>'; ?>
			<br>
			<h3><i class="fa fa-map-marker"></i>Address</h3>
            <?php echo '<h5> &nbsp; &nbsp; &nbsp ' . $row['cust_address'] . '</h5>'; ?>
            <br>
            <h3><i class="fa fa-at"></i> Email Address</h3>
            <?php echo '<h5> &nbsp; &nbsp; &nbsp ' . $row['cust_email'] . '</h5>'; ?>
        </div>
			<?php }?>
		<br>
		
    </div>
    <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>