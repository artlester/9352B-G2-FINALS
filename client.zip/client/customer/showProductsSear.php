<?php include 'session.php';?>
<?php include('db.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Search Result</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
</head>
<body style="background-color:#e3e3e3">
    <?php include 'userbar.php' ?>
    <div style="background:url(./img/heading.jpeg)">
		<center>
		<?php include 'advertisement.html';?>
		</center>
    </div>
    <div class="container-fluid bg-black" id="bg-black">
        <div class="container">
            <nav class="nav nav-pills nav-fill">
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=speaker"><h3>Speakers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=equalizer"><h3>Equalizers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=amplifier"><h3>Amplifiers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=bundle"><h3>Bundles</h3></a>
				<h3 class="nav-item" style="width:350px;float:left;padding;"><?php include'miniSearchBar.html';?></h3>
            </nav>
        </div>
    </div>
    <br>
    <div>
	<div> 
	<?php include 'search.php'?>
	</div>
	
    <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>