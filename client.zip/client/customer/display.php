<?php
$sql ="SELECT sound_id, name, duration, status, product_image,price, DATE_FORMAT(date_availability, '%M %d,%Y')as 
		 date_availability FROM sounds WHERE (NOT status = 'permanently unavailable') AND
		 (date_availability > DATE_SUB(NOW(), INTERVAL 1 WEEK)) ORDER BY sound_id DESC";
		 
		 $result=mysqli_query($mysqli,$sql);
               $queryResults=mysqli_num_rows($result);
			   if($queryResults > 0){
						
			?>
			<div class="mid-div" style="width:80%;margin:auto;">
			<?php
                while($product = mysqli_fetch_array($result)){
            ?>
			<div class="card-body prod-hover col-md-4" style="width:400px;float:left;text-align:center;height:550px;font-family:Roboto;line-height:5px;">
				<!--form action="http://customer.audirentur.com/view.php" method="post"-->
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); padding:3% 1%;">
						<div class="new-note"><h4><b>NEW!</b></h4></div>
	
						<div class="card-img-top">
						<img src="http://audirentur.service.com:3000/uploads/<?php echo $product['product_image']?>"  style="width:210px;height:200px;"/>
						<h4 class="card-title"><b><?php echo $product['name']; ?></b></h4><br>
						<div class="info-list-sect">
						<ul class="infos">
						<li>Available:&nbsp;<?php echo $product['date_availability'];?></li>
						<li>Status:&nbsp;<?php echo strtoupper($product['status']); ?></li>
						<li>PHP <?php echo $product['price'];?></li></ul>
						</div>
						<hr>
						<input name="sound_id" type="hidden" value="<?php echo $product['sound_id'];?>"/>
						<a href="http://customer.audirentur.com/view.php?sound_id=<?php echo $product['sound_id'];?>"style="color:white;"><button class="btn btn-primary" style="padding:2px 65px 2px 65px;">
						View
						</button></a>
						</div>
				</div>
			</div>
				<?php
						}
			   }	
						?>
			</div>
<?php	
		 $sql ="SELECT sound_id, name, status, product_image,price, DATE_FORMAT(date_availability, '%M %d,%Y')as 
		 date_availability FROM sounds WHERE (NOT status ='permanently unavailable') AND (NOT date_availability > DATE_SUB(NOW(), INTERVAL 1 WEEK)) ORDER BY sound_id DESC";
		 
		 $result=mysqli_query($mysqli,$sql);
               $queryResults=mysqli_num_rows($result);
                    if($queryResults > 0){
						
			?>
			<div>
			<?php
                while($product = mysqli_fetch_array($result)){
            ?>
			<div class="card-body prod-hover col-md-4" style="width:400px;float:left;text-align:center;height:550px;font-family:Roboto;line-height:5px;">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); padding:3% 1%;">
						<div class="card-img-top">
						<img src="http://audirentur.service.com:3000/uploads/<?php echo $product['product_image']?>"  style="width:210px;height:200px;"/>
						</div>
						<h4 class="card-title"><b><?php echo $product['name']; ?></b></h4><br>
						<div class="info-list-sect">
						<ul class="infos">
						<li>Available:&nbsp;<?php echo $product['date_availability'];?></li>
						<li>Status:&nbsp;<?php echo strtoupper($product['status']); ?></li>
						<li>PHP <?php echo $product['price'];?></li></ul>
						</div>
						<hr>
						<a href="http://customer.audirentur.com/view.php?sound_id=<?php echo $product['sound_id'];?>" style="color:white;"><button class="btn btn-primary" style="padding:2px 65px 2px 65px;">
						View
						</button></a>
                    </div>
				</div>
				<?php
						}
						
						?>
			</div>
				<?php
                    }
					?>
				
				