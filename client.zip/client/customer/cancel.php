<?php
	require('db.php');
	require('session.php');
	
$rental_id=$_GET["id"];
$cancel="cancelled";

if(isset($_GET["action"])){
		if($_GET["action"] == "cancel"){
				$query = "UPDATE rentals SET status = '$cancel' WHERE rental_id = '$rental_id'";
				
				$result = mysqli_query($mysqli, $query);
				
				if(!$result ){
					die('Could not display data: ' . mysql_error());
				}else{
					echo '<script>alert("Rental Cancelled")</script>';
					echo '<script>window.location="transactions.php"</script>';
				}
		}elseif($_GET["action"] == "delete"){
			$query = "DELETE FROM rentals WHERE rental_id='$rental_id'";
				
				$result = mysqli_query($mysqli, $query);
				
				if(!$result ){
					die('Could not display data: ' . mysql_error());
				}else{
					echo '<script>alert("Record Deleted")</script>';
					echo '<script>window.location="transactions.php"</script>';
				}
		}	
}
?>