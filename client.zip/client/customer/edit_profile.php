<?php
require_once('session.php');
include ('db.php');
?>
<html>
   
   <head>
	<meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Edit Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">

   </head>
   
   <body style="margin:0; background: 	#D3D3D3;">
       <br>
       <br>

<form  method = "POST" action="#">
<p style="font-size:40px; text-align:center; background-color:#359CCB;">Update profile info</p>
            <br>
            <br>
  <table align="center">     
       
      <tr>
          <td style="border: 1px solid 	#202020; background-color:#E8E8E8; font-size: 23px;"><p class="popupp" style="text-align:center;">Username</p></td>
          <td><input name="username" class="popupinput" value=<?php echo $_SESSION['username']; ?> 
                     style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
              background: #FAFAFA; " required/></td></tr>
    
        <tr>
            <td style="border: 1px solid 	#202020;  background-color:#E8E8E8; font-size: 23px;"><p class="popupp" style="text-align:center;">First-name</p></td>
            <td><input name="firstname" class="popupinput" value=<?php echo $_SESSION['firstname']; ?> style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                background: #FAFAFA; " required/></td></tr>

      <tr>
            <td style="border: 1px solid 	#202020;  background-color:#E8E8E8; font-size: 23px;"><p class="popupp" style="text-align:center;">Last-name</p></td>
            <td><input name="lastname" class="popupinput" value=<?php echo $_SESSION['lastname']; ?> style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                background: #FAFAFA; " required/></td></tr>
    
      <tr>
          <td style="border: 1px solid 	#202020;  background-color:#E8E8E8; font-size: 23px;"><p class="popupp" style="text-align:center;">Gender</p></td>
          <td>
            <select name="gender" class="popupinput" value=<?php echo $_SESSION['gender']; ?> style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                background: #FAFAFA; " required/>>
              <option value="Female">Female</option>
              <option value="Male">Male</option>
            </select></td></tr>
    
      <tr>
          <td style="border: 1px solid 	#202020;  background-color:#E8E8E8; font-size: 23px;"><p class="popupp" style="text-align:center;">Contact Number</p></td>
      <td><input name="contact" class="popupinput" value=<?php echo $_SESSION['contact']; ?> style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
          background: #FAFAFA; " required/></td></tr>

      <tr>
          <td style="border: 1px solid 	#202020;  background-color:#E8E8E8; font-size: 23px;"><p class="popupp" style="text-align:center;">Email</p></td>
            <td><input name="email" value=<?php echo $_SESSION['email']; ?> style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                background: #FAFAFA; " required/></td></tr>
    
      <tr>
          <td style="border: 1px solid 	#202020;  background-color:#E8E8E8; font-size: 23px;"><p class="popupp" style="text-align:center;">Bio</p></td>
            <td><textarea name="bio" class="popupinput" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                background: #FAFAFA; " required><?php echo $_SESSION['bio']; ?></textarea><td></td></tr>
				
		 <tr>
          <td style="border: 1px solid 	#202020;  background-color:#E8E8E8; font-size: 23px;"><p class="popupp" style="text-align:center;">Address</p></td>
            <td><textarea name="address" class="popupinput" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                background: #FAFAFA; " required><?php echo $_SESSION['address']; ?></textarea><td></td></tr>
    <tr>
        <td><a href="http://customer.audirentur.com/profile.php" style="background-color: red;
                    color: white;
                    padding: 14px 20px;
                    margin: 0 auto;
                    margin-top:20px;
                    position:relative;  
                    display:block;
                    cursor: pointer;
                    width: 280px;
                    text-align:center;
                 opacity: 0.9;  ">Cancel</a></td>
        <td><input name="submit" type="submit" value="SUBMIT" style="background-color: #4CAF50;
                    color: white;
                    padding: 14px 20px;
                    margin: 0 auto;
                    margin-top:20px;
                    position:relative;  
                    display:block;
                    cursor: pointer;
                    width: 280px;
        opacity: 0.9;  "/></td></tr>
</form>
</table> 
<?php

if(isset($_POST['submit'])){
    
    $username = mysqli_real_escape_string($mysqli, $_POST['username']);
    $firstname = mysqli_real_escape_string($mysqli, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($mysqli, $_POST['lastname']);
    $gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
    $contact = mysqli_real_escape_string($mysqli, $_POST['contact']);
    $email = mysqli_real_escape_string($mysqli, $_POST['email']);
    $bio = mysqli_real_escape_string($mysqli, $_POST['bio']);
	$address = mysqli_real_escape_string($mysqli, $_POST['address']);
    
    $customer_id = $_SESSION['customer_id'];
    $newsession = $customer_id;


    $sql = "UPDATE customers SET cust_username = '$username',cust_first_name = '$firstname',cust_last_name ='$lastname',
	cust_bio = '$bio',cust_address ='$address', cust_gender = '$gender', cust_contact_number = '$contact', cust_email = '$email' WHERE customer_id = $customer_id ";

    $resultupdate = mysqli_query($mysqli, $sql);
    if($resultupdate){
        
        $_SESSION['username'] = $username;
        $_SESSION['firstname'] = $firstname; 
        $_SESSION['lastname'] = $lastname; 
        $_SESSION['gender'] = $gender;
        $_SESSION['contact'] = $contact; 
        $_SESSION['email'] = $email; 
        $_SESSION['bio'] = $bio; 

        $url = "http://customer.audirentur.com/profile.php";
        $messageok = 'User data updated!';
        echo "<script type='text/javascript'>alert('$messageok');</script>";
        echo '<script>window.location = "'.$url.'";</script>';
        
    }else{
        mysqli_error($resultupdate);
        $url = "http://customer.audirentur.com/edit_profile.php";
        echo '<script>window.location = "'.$url.'";</script>';
        
    } 


}
?>
    </body>
</html>