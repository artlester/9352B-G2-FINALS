<div class="table" style="padding-bottom:100px;">
<?php
	$query = "SELECT rentals.rentals_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name 
				FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
				INNER JOIN sounds on rentals.sound_id=sounds.sound_id) WHERE customers.cust_username= '$user' 
				AND rentals.status= 'Pending' ORDER BY rentals.rentals_id desc";
		
	$result = mysqli_query($mysqli, $query);
	if(!$result ) {
				die('Could not display data: ' . mysql_error()); //display errors 
	}
	?>
	<h3 >Pending Rentals</h3>
	<br>
	<table class="table table-striped">
			<thead class="thead-dark">
				<tr>
					<th width="20%">Name of Package</th>
					<th width="5%">Rental Date</th>
					<th width="5%">Return Date</th>
					<th width="5%">Status</th>
					<th width="5%">Action</th>
				</tr>
			</thead>
			<tbody>
			<?php	//for the data will be displayed
				$no=1;
				while ($row = mysqli_fetch_array($result)){
				echo '<tr>
						<td >'.$row['name'].'</td>
						<td >'.$row['rental_date'].'</td>
						<td >'.$row['return_date'].'</td>
						<td >'.$row['status'].'</td>
						<td ><a href="cancel.php?action=cancel&id='.$row['rentals_id'].'">
						<span class="text-danger">cancel</span></a></td>
					</tr>';
					$no++;
			}	
		
			?>
			</tbody>
	</table>
	<div >
	<br>
	<h3 >Recent Rentals</h3>
	<br>
	<hr>
	<div>
	<?php
	$query = "SELECT rentals.rentals_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name 
				FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
				INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
				WHERE customers.cust_username= '$user' AND rentals.status= 'Renting'";
		
	$result = mysqli_query($mysqli, $query);
	if(!$result ) {
				die('Could not display data: ' . mysql_error()); //display errors 
	}
	?>
	<h4>Renting</h4>
	<table class="table table-striped">
			<thead class="thead-dark">
				<tr class="table100-head">
					<th >Name of Package</th>
					<th >Rental Date</th>
					<th >Return Date</th>
					<th >Status</th>
				</tr>
			</thead>
			<tbody>
			<?php	//for the data will be displayed
				$no=1;
				while ($row = mysqli_fetch_array($result)){
				echo '<tr>
						<td >'.$row['name'].'</td>
						<td >'.$row['rental_date'].'</td>
						<td >'.$row['return_date'].'</td>
						<td >'.$row['status'].'</td>
					</tr>';
					$no++;
			}?>
			</tbody>
	</table>
	</div>
	<br>
	<hr>
	<div>
	<?php
	$query = "SELECT rentals.rentals_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name 
				FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
				INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
				WHERE customers.cust_username= '$user' AND rentals.status= 'finished'";
		
	$result = mysqli_query($mysqli, $query);
	if(!$result ) {
				die('Could not display data: ' . mysql_error()); //display errors 
	}
	?><h4>Rented</h4>
	<table class="table table-striped">
			<thead class="thead-dark">
				<tr class="table100-head">
					<th >Name of Package</th>
					<th >Rental Date</th>
					<th >Return Date</th>
					<th >Status</th>
				</tr>
			</thead>
			<tbody>
			<?php	//for the data will be displayed
				$no=1;
				while ($row = mysqli_fetch_array($result)){
				echo '<tr>
						<td >'.$row['name'].'</td>
						<td >'.$row['rental_date'].'</td>
						<td >'.$row['return_date'].'</td>
						<td >'.$row['status'].'</td>
					</tr>';
					$no++;
			}?>
			</tbody>
	</table>
	</div>
	<br>
	<hr>
	<div>
	<?php
	$query = "SELECT rentals.rentals_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
				DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name 
				FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
				INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
				WHERE customers.cust_username= '$user' AND rentals.status= 'Cancelled'";
		
	$result = mysqli_query($mysqli, $query);
	if(!$result ) {
				die('Could not display data: ' . mysql_error()); //display errors 
	}
	?><h4>Cancelled Rentals</h4>
	<table class="table table-striped">
			<thead class="thead-dark">
				<tr class="table100-head">
					<th >Name of Package</th>
					<th >Rental Date</th>
					<th >Return Date</th>
					<th >Status</th>
					<th >Action</th>
				</tr>
			</thead>
			<tbody>
			<?php	//for the data will be displayed
				$no=1;
				while ($row = mysqli_fetch_array($result)){
				echo '<tr>
						<td >'.$row['name'].'</td>
						<td >'.$row['rental_date'].'</td>
						<td >'.$row['return_date'].'</td>
						<td >'.$row['status'].'</td>
						<td ><a href="cancel.php?action=delete&id='.$row['rentals_id'].'">
						<span class="text-danger">delete</span></a></td>
					</tr>';
					$no++;
			}?>
			</tbody>
	</table>
	</div>
	</div>
</div>
