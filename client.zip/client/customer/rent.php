<?php require ('db.php');require ('session.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Rent</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
	<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fonts.css">
	<style>
	.info-div {
		background-color: white; 
		padding: 20px;
		border-radius:5px;
	}
	
	</style>
</head>
<body style="background-color:#e3e3e3;">
    <?php include 'userbar.php' ?>
    <div style="background:url(./img/heading.jpeg)">
		<center>
		<?php include 'advertisement.html';?>
		</center>
    </div>
    <div class="container-fluid bg-black" id="bg-black">
        <div class="container">
            <nav class="nav nav-pills nav-fill">
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=speaker">Speakers</a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=equalizer">Equalizers</a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=amplifier">Amplifiers</a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=bundle">Bundles</a>
            </nav>
        </div>
    </div>
<div style="padding-bottom:100px;">
<?php 
if(isset($_GET['id'])){
	$sound_id=$_GET['id'];
	
	$query= "SELECT * FROM sounds NATURAL JOIN vendors WHERE sounds.sound_id='$sound_id'";
	$result = mysqli_query($mysqli, $query);

?>
<div>
	<?php include 'events.php'?>
</div>
<?php
	$query= "SELECT * FROM sounds NATURAL JOIN vendors WHERE sounds.sound_id='$sound_id'";
	$result = mysqli_query($mysqli, $query);
        while ($row = mysqli_fetch_assoc($result)){
			$availability=date_create($row['date_availability']);
?>
	<form method = "post" action="http://customer.audirentur.com/insert.php" style="width:100%;font-family:Roboto;">
		<div style="width:60%;float:left; margin-left:5%;margin-right: 1%;padding: 20px;border-radius:5px;">
			<div style="padding: 20px; border-radius: 5px;"  class="info-div">
			<h3><b><?php echo $row['name']; ?></b></h3>
			<ul style="list-style:none; font-size: 25px;">
			<li><b>Price:</b>&nbsp;Php&nbsp;<?php echo $row['price']?>.00</li>
			<li><b>Available:</b>&nbsp;<?php echo date_format($availability,"F d, Y");?></li>
			<li><b>Status:&nbsp;</b><b><?php echo strtoupper($row['status']); ?></b></li>
			<hr>
			<li><b>Description:</b>&nbsp;<p style="font-size:20px;text-align:left;margin-right:30px;"><?php echo $row['description']?><p></li>
			</ul>
				</div>
			<div style="width:100%;display:inline-block;padding: 30px;font-family:Roboto;border:1px groove;margin-top:20px;" class="info-div">
		<!--form action="http://customer.audirentur.com/vendor.php" method="post"-->
			<h3><b>Vendor Name:</b>&nbsp;<?php echo $row['ven_username']?></h3>
			<ul style="list-style: none;">
			<li style="font-size: 20px;">
			<b>Contact:&nbsp;</b>
			<ul style="list-style: none;">
			<li><?php echo $row['ven_contact_number']?></li>
			<li><?php echo $row["ven_email"];?></p></li></li>
			</ul></ul><br>
		</div>
		</div>	
		<div style="width:30%;float:left;padding:20px 20px 30px 20px;background-color:white;border-radius:5px;margin-top:20px;">
		<h1 style="font-family:UrbanJungleDEMO;font-size:70px;text-align:center;">RENT</h1>
		<center>
			<img src="http://audirentur.service.com:3000/uploads/<?php echo $row['product_image']?>"  style="width:20vw;height:auto;background-color:white;"/>
			</center>
			<div>
			<ul style="list-style: none;font-size:20px">
			<li>Rental Date:&nbsp;<input type="date" name="rental_date" id="rental_date" 
			style="width:50%;height:30px;"/></li>
			<li>Return Date:
			<input type="date" name="return_date" id="return_date" 
			style="width:50%;height:30px;"/></li></ul>
			</div>
			<input name="sound_id" type="hidden" value="<?php echo $row['sound_id'];?>"/>
			<input type="submit" name="insert" class="btn btn-primary" style="width:100%"/></h2>
		</div>		
	</form>
</div>
<?php }
}
?>
</div>
 <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>