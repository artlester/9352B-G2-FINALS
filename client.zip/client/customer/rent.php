<?php require ('db.php');require ('session.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Rent</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
	<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fonts.css">
</head>
<body style="background-color:#e3e3e3;">
    <?php include 'userbar.php' ?>
    <div style="background:url(./img/heading.jpeg)">
		<center>
		<?php include 'advertisement.html';?>
		</center>
    </div>
    <div class="container-fluid bg-black" id="bg-black">
        <div class="container">
            <nav class="nav nav-pills nav-fill">
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=speaker">Speakers</a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=equalizer">Equalizers</a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=amplifier">Amplifiers</a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=bundle">Bundles</a>
            </nav>
        </div>
    </div>
<div style="padding-bottom:100px;">
<?php 
$sound_id=$_SESSION['sound_id'];

if(isset($_POST['rent'])){
	$query= "SELECT * FROM sounds NATURAL JOIN vendors WHERE sounds.sound_id='$sound_id'";
	$result = mysqli_query($mysqli, $query);
	
        while ($row = mysqli_fetch_assoc($result)){
?>
	<form method = "post" action="http://customer.audirentur.com/rent.php?insert" style="width:100%;font-family:RenaultBQ-Light;">
		<div style="width:60%;float:left;text-align:center;">
			<div>
			<h1><?php echo $row['name']; ?></h1>
			<h2>Duration:&nbsp;<?php echo $row['duration']; ?>&nbsp;days</h2>
			<h2>Price:&nbsp;Php&nbsp;<?php echo $row['price']?>.00</h2>
            <h2>Available:&nbsp;<?php echo $row['date_availability'];?></h2>
            <h2>Status:&nbsp;<i><?php echo strtoupper($row['status']); ?></i></h2> 
			<p style="font-size:20px;text-align:left;margin-right:30px;"><b>Description:</b>&nbsp;<?php echo $row['description']?><p>
			<h1>Vendor name:&nbsp;<?php echo $row['ven_username']?></h1>
			<h3>Contact:&nbsp;<?php echo $row['ven_contact_number']?></h3>
			<h3 ><?php echo $row["ven_email"];?></h5><br>
			</div>
		</div>	
		<div style="width:30%;float:left;padding-bottom:100px;">
		<h1 style="font-family:UrbanJungleDEMO;font-size:100px;">RENT</h1>
			<center>
			<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $row['product_image']).'" style="width:20vw;height:auto;background-color:white;"/>'?>
			</center>
			<h2>Rental Date:&nbsp;<input type="date" name="rental_date" id="rental_date" 
			style="width:50%;height:40px;"/></h2>
			<h2>Return Date:
			<input type="date" name="return_date" id="return_date" 
			style="width:50%;height:40px;"/>
			<input type="submit" name="insert" class="btn btn-primary" /></h2>
		</div>		
	</form>
</div>
<?php 
	}
}
if(isset($_POST['insert'])){
	$return_date=$_POST['return_date'];
	$rental_date=$_POST['rental_date'];
	if(empty($return_date) || strtotime($return_date) < strtotime($rental_date)){
		echo '<script>alert("No Return Date or Entered invalid date.")</script>';
		$query= "SELECT * FROM sounds NATURAL JOIN vendors WHERE sounds.sound_id='$sound_id'";
	$result = mysqli_query($mysqli, $query);
	
        while ($row = mysqli_fetch_assoc($result)){
			$sound_id=$row['sound_id'];
?>
	<form method = "post" action="http://customer.audirentur.com/rent.php?insert" style="width:100%">
		<div style="width:50%;float:left;padding-bottom:100px">
			<h1><?php echo $row['name']; ?></h1>
			<h2>Duration:&nbsp;<?php echo $row['duration']; ?>&nbsp;days</h2>
			<h2>Price:&nbsp;Php&nbsp;<?php echo $row['price']?>.00</h2>
            <h2>Available:&nbsp;<?php echo $row['date_availability'];?></h2>
            <h2>Status:&nbsp;<i><?php echo strtoupper($row['status']); ?></i></h2> 
			<p style="font-size:20px;"><b>Description:</b>&nbsp;<?php echo $row['description']?><p>
			<h1>Vendor name:&nbsp;<?php echo $row['ven_username']?></h1>
			<h3>Contact:&nbsp;<?php echo $row['ven_contact_number']?></h3>
		</div>
		<div style="width:50%;float:left;padding-bottom:100px;">
		<h1 style="font-family:UrbanJungleDEMO;font-size:100px;">RENT</h1>
			<center>
			<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $row['product_image']).'" style="width:20vw;height:auto;"/>'?>
			</center>
			<h2>Rental Date:&nbsp;<input type="date" name="rental_date" id="rental_date" 
			style="width:50%;height:40px;"/></h2>
			<h2>Return Date:
			<input type="date" name="return_date" id="return_date" 
			style="width:50%;height:40px;"/>
			<input type="submit" name="insert" class="btn btn-primary" /></h2>
		</div>		
	</form>

<?php
		}
	}else{
	$query0 = "SELECT customer_id FROM customers WHERE cust_username = '$user'";
	$result0=mysqli_query($mysqli,$query0);
	while($product = mysqli_fetch_assoc($result0)){
		$customer_id = $product['customer_id'];
	}
	$query1 = "INSERT INTO rentals (`sound_id`,`customer_id`, `rental_date`,`return_date`) VALUE('$sound_id','$customer_id','$rental_date','$return_date')";
	$result1 = mysqli_query($mysqli, $query1);
	if ($result1) {
	echo '<script>alert("Rental Successful.")</script>';
	echo '<h1>Browse and rent <a href="http://customer.audirentur.com/homepage.php">more</a></h1>';
	} else {
    echo "Error: " . $query1 . "<br>" . mysqli_error($mysqli);
	}
	}
}
?>
</div>
 <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>