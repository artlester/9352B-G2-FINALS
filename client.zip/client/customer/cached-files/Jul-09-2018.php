	<html>
		output all your html here.
	</html>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: View</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
	<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fonts.css">
	<style>
		.prod-img {
		border: 10px solid rgba(194, 198, 195, 0.6);
		border-radius: 7px;
	}
	
	.info-div {
		background-color: white; 
		padding: 20px;
		border-radius:5px;
		border: 10px solid #C2C6C3;
	}
	</style>
</head>
</head>
<body style="background-color:#e3e3e3">
    <nav class="navbar navbar-expand navbar-dark py-md-0"  style="font-size:20px;background-color:#323433">
        <ul class="navbar-nav mr-auto">
        <li class="nav-item py-0">
             <a class="nav-link text-light" href="./homepage.php"><i class="fas fa-home"></i>&nbsp;Audirentur</a></li>
        </ul>
        <ul class="navbar-nav ml-auto">
			<li class="nav-item py-0">
				<div>
				<img src="img/default_avatar_female.jpg" id="profile-picture" width="60px" height="60px">				</div>
			</li>
            <li class="nav-item dropdown py-0">
                <a class="nav-link dropdown-toggle text-light" id="navbarDropdownMenuLink" data-toggle="dropdown" href="javascript:void(0)">user5</a>                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" id="drop-down" href="http://customer.audirentur.com/profile.php"><i class="fas fa-user"></i> &nbsp;Profile</a>
                    <a class="dropdown-item" id="drop-down" href="http://customer.audirentur.com/transactions.php"><i class="fas fa-credit-card"></i> Transactions</a>
                    <a class="dropdown-item" id="drop-down" href="http://customer.audirentur.com/logout.php"><i class="fas fa-sign-out-alt"></i> &nbsp;Logout</a>
                </div>
            </li>
            <li class="nav-item py-0"><a class="nav-link text-light" id="socio-icon" href="https://bit.ly/2KD6yAw" target="_blank"><i class="fab fa-facebook"></i></a></li>
            <li class="nav-item py-0"><a class="nav-link text-light" id="socio-icon" href="https://bit.ly/2wY5DIF" target="_blank"><i class="fab fa-twitter"></i></a></li>
            <li class="nav-item py-0"><a class="nav-link text-light" id="socio-icon" href="https://bit.ly/2ITqVfA" target="_blank"><i class="fab fa-google-plus"></i></a></li>
        </ul>
</nav>
    <div style="background:url(./img/heading.jpeg)">
		<center>
		<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<body>
<div class="container">
  <img class="mySlides" src="./img/Ad.jpg" style="width:100%;max-height:10%;">
  <img class="mySlides" src="./img/Ad1.jpg" style="width:100%; max-height:10%;">
  <img class="mySlides" src="./img/Ad2.jpg" style="width:100%; max-height:10%;">
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 3000); // Change image every 2 seconds
}
</script>

</body>
</html>		</center>
    </div>
    <div class="container-fluid bg-black" id="bg-black">
        <div class="container">
            <nav class="nav nav-pills nav-fill">
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=speaker"><h3>Speakers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=equalizer"><h3>Equalizers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=amplifier"><h3>Amplifiers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=bundle"><h3>Bundles</h3></a>
				<h3 class="nav-item" style="width:350px;float:left;padding;"><div id="minisearch" style="padding:5px;">
    <form action="showProductsSear.php" method="POST">
        <div class="container input-group">
            <input class="form-control py-2" type="search" name="search" placeholder="Search for systems..." required>
            <div class="input-group-append">
                <button class="btn btn-outline-secondary" type="search" name="submit-search">
                    <i class="fa fa-search"></i>
                </button>
            </div>
        </div>
    </form>
</div></h3>
			</nav>
        </div>
    </div>
    <br>
	<div>
 			
		<div style="width:40%;height:500px;float:left;text-align:center;background:white;margin:0 40px; padding: 40px 10px 10px 10px;" class="prod-img">
		<img src="http://audirentur.service.com:3000/uploads/image-1530879608940.png" 
		style="width:25vw;overflow:auto;vertical-align:center;"/>
		</div>
		<div style="width:50%;float:left;padding: 30px;font-family:RenaultBQ-Light;border:1px groove;" class="info-div">
		<form action="http://customer.audirentur.com/rent.php" method="post">

			<h1><b>Sakura EQ-800 15 Band Stereo Graphic Equalizer</b></h1>
			<ul style="list-style:none; font-size: 25px;">
			<li><b>Price:</b>&nbsp;Php&nbsp;400.00</li>
			<li><b>Available:</b>&nbsp;June 22,2018</li>
			<li><b>Status:&nbsp;</b><b>RENTED</b></li>
			<br>
			<li><b>Description:</b>&nbsp;<p style="font-size:20px;text-align:left;margin-right:30px;">15 Band MCU Graphic Equalizer
Spectrum Analyzer
220V VOLT AC
Dual Colored Sliding Display<p></li>
			</ul>
			<input name="sound_id" type="hidden" value="20"/>
			<input type="submit" name="rent" value="RENT" class="btn btn-primary" style="padding:6px 30px 6px 30px;width:100%;margin:auto;margin-top:10px;border-radius:5px;"/>
        </form>
		<hr>
		<form action="http://customer.audirentur.com/vendor.php" method="post">
			<h3><b>Vendor Name:</b>&nbsp;john</h3>
			<ul style="list-style: none;">
			<li style="font-size: 20px;">
			<b>Contact:&nbsp;</b>
			<ul style="list-style: none;">
			<li>09123506029</li>
			<li>johndoe@gmail.com</p></li></li>
			</ul></ul><br>
			<input name="vendor_id" type="hidden" value="1"/>
			<input type="submit" name="view" value="View Profile" class="btn btn-primary" style="padding:6px 30px 6px 30px;width:100%;margin:auto;margin-top:10px;border-radius:5px;"/>
			</form>
		</div>
</div>
</div>


	
    <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>
