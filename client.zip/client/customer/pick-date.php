<div>
		<div>
		<form method="post" style="text-align:center">
		<table>
			<tr>
			<td><input type="submit" name="filt-trans" value="FIND" style="font-size:15px;background-color:#E1D92A;" class="btn btn-primary btntrans"/></td>
			<td><input type="submit" name="t-trans" value="TODAY" style="font-size:15px;"class="btn btn-primary btntrans"/></td>
			<td><input type="submit" name="mon-trans" value="MONTH" style="font-size:15px;background-color:#B654AC;"class="btn btn-primary btntrans"/></td>
			<td><input type="submit" name="rentals-trans" value="RECEIPT" style="font-size:15px;background-color:#50C83D;" class="btn btn-primary btntrans"/></td>
			</tr>

		</table>
		</form>
		</div>
		<hr>
	<div style="overflow-y:scroll;height:50em;padding:10px;border: 4px solid #220F23;">
		<?php
		if(isset($_POST['t-trans'])){
			$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
							DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name 
							FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
							INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
								WHERE customers.cust_username= '$user' AND Date(rental_date) = Date(NOW())";
						$result = mysqli_query($mysqli, $query);
						$queryresults = mysqli_num_rows($result);
						if ($queryresults !=0){
						$no=1;
						while ($row = mysqli_fetch_array($result)){
							echo '<hr><form style="background-color:whitesmoke;padding:10px;border: 2px solid white;">
									
									<h3>'.$row['name'].'</h3>
									<p><b>Rental Date: </b>'.$row['rental_date'].'</p>
									<p><b>Return Date: </b>'.$row['return_date'].'</p>
									<p><b>Status: </b>'.$row['status'].'</p>
									
									</form>';
								$no++;
						}
						}else{
						echo '<h1 style="font-size:90px;font-family:UrbanJungleDEMO;text-align:center;">NONE</h1>';
						}
		}
		if(isset($_POST['mon-trans'])){
			$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
							DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name, 
							sounds.price, vendors.ven_username
							FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id)
							INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
							INNER JOIN vendors on sounds.vendor_id=vendors.vendor_id
								WHERE customers.cust_username= '$user' AND rentals.rental_date > DATE_SUB(NOW(), INTERVAL 1 MONTH);";
						$result = mysqli_query($mysqli, $query);
						$queryresults = mysqli_num_rows($result);
						if ($queryresults !=0){
						$no=1;
						while ($row = mysqli_fetch_array($result)){
							echo '<hr><form style="background-color:whitesmoke;padding:10px;border: 2px solid white;">
									
									<h4>'.$row['name'].'</h4>
									<ul style="list-style:none;font-size:18px;">
									<li><b>Rental Date: </b>'.$row['rental_date'].'</li>
									<li><b>Return Date: </b>'.$row['return_date'].'</li>
									<li><b>Vendor:</b>'.$row['ven_username'].'</li>
									<li><b>Status: </b>'.$row['status'].'</li>
									</ul>
									</form>';
								$no++;
						}
						}else{
						echo '<hr><h1 style="font-size:30px;font-family:The Bully;text-align:center;">NONE</h1>';
						}
		}
			?>
			<?php
			if(isset($_POST['filt-trans'])){
				echo '
			<div style="width:100%">
				<form method="post" action="'.$_SERVER['PHP_SELF'].'">
					<h2>Choose Date!</h2>
					<div class="container input-group">
						<input type="date" style="font-size:20px;width:30%;" name="rental_date" class="form-control py-2"/>
						<div class="input-group-append">
						<input type="submit" name="pickdate" style="padding:0 25px 0 25px"/>
						</div>
					</div>
				</form>';
			}
if(isset($_POST['pickdate'])){
				$rental_date=$_POST['rental_date'];
					$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
							DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name 
							FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
							INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
								WHERE customers.cust_username= '$user' AND rentals.rental_date= '$rental_date'";
						$result = mysqli_query($mysqli, $query);
						
						$queryresults = mysqli_num_rows($result);
			?>
			<div>
				<h2>Date:&nbsp;<?php echo $rental_date;?></h2>
				</div>
					
				<?php 
				
						if ($queryresults !=0){
						$no=1;
						while ($row = mysqli_fetch_array($result)){
							echo '<form style="background-color:powderblue;width:300px;border: 2px solid white;" >
									
									<h4>'.$row['name'].'</h4>
									<ul style="list-style:none; font-size:18px;">
									<li><b>Rental Date: </b>'.$row['rental_date'].'</li>
									<li><b>Return Date: </b>'.$row['return_date'].'</li>
									<li><b>Status: </b>'.$row['status'].'</li>
									</ul>
									</form>';
								$no++;
						}
						}else{
						echo '<br><p style="font-size:30px;">No Rental Activities...</p>';
						}
				
				}			
				?>
				<?php
			if(isset($_POST['rentals-trans'])){
				$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
							DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name, 
							sounds.price, vendors.ven_username
							FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id)
							INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
							INNER JOIN vendors on sounds.vendor_id=vendors.vendor_id
								WHERE customers.cust_username= '$user' AND rentals.status='finished'";
						$result = mysqli_query($mysqli, $query);
						$queryresults = mysqli_num_rows($result);
						if ($queryresults !=0){
						$no=1;
						while ($row = mysqli_fetch_array($result)){
							$strttime=date_create($row['rental_date']);
							$endtime=date_create($row['return_date']);
							 $diff = date_diff($strttime,$endtime);
							 $amount=$row['price'];
							 $days=$diff->format("%R%a days");
							 $total = $days * $amount;
							 
							echo '<hr><form style="background-color:whitesmoke;padding:10px;border: 2px solid white;">
									
									<h4>'.$row['name'].'</h4>
									<ul style="list-style:none;font-size:18px;">
									<li><b>Rental Date: </b>'.$row['rental_date'].'</li>
									<li><b>Return Date: </b>'.$row['return_date'].'</li>
									<hr>
									<li><b>Amount Paid:&nbsp;</b>Php&nbsp;'.$total.'</li>
									<li><b>Vendor Name: </b>'.$row['ven_username'].'</li>
									<li><b>Status: </b>'.$row['status'].'</li>
									</ul>
									</form>';
								$no++;
						}
						}else{
						echo '<h1 style="font-size:90px;font-family:UrbanJungleDEMO;text-align:center;">NONE</h1>';
						}
				
				}			
				?>
		</div>
	</div>	
</div>