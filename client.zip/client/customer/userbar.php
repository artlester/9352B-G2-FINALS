<nav class="navbar navbar-expand navbar-dark py-md-0"  style="font-size:20px;background-color:#323433">
        <ul class="navbar-nav mr-auto">
        <li class="nav-item py-0">
             <a class="nav-link text-light" href="./homepage.php"><i class="fas fa-home"></i>&nbsp;Audirentur</a></li>
        </ul>
        <ul class="navbar-nav ml-auto">
			<li class="nav-item py-0">
				<div>
				<?php
				$query="SELECT * FROM customers WHERE cust_username='$user'";
				$result=mysqli_query($mysqli,$query);
				while($row = mysqli_fetch_array($result)){
					if(empty($row['cust_avatar'])) {
						if($row['cust_gender'] == "Male") {
							echo '<img src="img/default_avatar_male.jpg" id="profile-picture" width="60px" height="60px">';
						} else {
							echo '<img src="img/default_avatar_female.jpg" id="profile-picture" width="60px" height="60px">';
						}
					} else {
					echo '<img src="data:img/jpg;base64,'.base64_encode( $row['cust_avatar']).'" style="width:60px;height:60px;"/>';
					}
				}?>
				</div>
			</li>
            <li class="nav-item dropdown py-0">
                <?php echo'<a class="nav-link dropdown-toggle text-light" id="navbarDropdownMenuLink" data-toggle="dropdown" href="javascript:void(0)">' . $user . '</a>'; ?>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" id="drop-down" href="http://customer.audirentur.com/profile.php"><i class="fas fa-user"></i> &nbsp;Profile</a>
                    <a class="dropdown-item" id="drop-down" href="http://customer.audirentur.com/transactions.php"><i class="fas fa-credit-card"></i> Transactions</a>
                    <a class="dropdown-item" id="drop-down" href="http://customer.audirentur.com/logout.php"><i class="fas fa-sign-out-alt"></i> &nbsp;Logout</a>
                </div>
            </li>
            <li class="nav-item py-0"><a class="nav-link text-light" id="socio-icon" href="https://bit.ly/2KD6yAw" target="_blank"><i class="fab fa-facebook"></i></a></li>
            <li class="nav-item py-0"><a class="nav-link text-light" id="socio-icon" href="https://bit.ly/2wY5DIF" target="_blank"><i class="fab fa-twitter"></i></a></li>
            <li class="nav-item py-0"><a class="nav-link text-light" id="socio-icon" href="https://bit.ly/2ITqVfA" target="_blank"><i class="fab fa-google-plus"></i></a></li>
        </ul>
</nav>
