<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/homepage-1.css">


<div style="padding-bottom:100px;width:90%;margin:auto;">
     <h1>Search Results:</h1>
    <?php
        if(isset($_POST['submit-search'])){
            
            $search = mysqli_real_escape_string($mysqli, $_POST['search']);
            $sql = "SELECT * FROM sounds s NATURAL JOIN categories c WHERE c.category LIKE '%$search%' OR s.name LIKE '%$search%'
                ORDER BY s.status";
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
    
            echo "There are " .$queryResults. " results!<br>";
			
			
            if($queryResults >0){
                while ($product = mysqli_fetch_assoc($result)){
					$availability=date_create($product['date_availability']);
					?>
				<div class="card-body prod-hover col-md-4" style="width:400px;float:left;text-align:center;height:550px;font-family:Roboto;line-height:5px;">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); padding:3% 1%;">
						<div class="card-img-top">
						<img src="http://audirentur.service.com:3000/uploads/<?php echo $product['product_image']?>"  style="width:210px;height:200px;"/>
						</div>
						<h4 class="card-title"><b><?php echo $product['name']; ?></b></h4><br>
						<div class="info-list-sect">
						<ul class="infos">
						<li>Available:&nbsp;<?php echo date_format($availability,"F d, Y");?></li>
						<li>Status:&nbsp;<?php echo strtoupper($product['status']); ?></li>
						<li>PHP <?php echo $product['price'];?></li></ul>
						</div>
						<hr>
						<a href="http://customer.audirentur.com/view.php?sound_id=<?php echo $product['sound_id'];?>" style="color:white;"><button class="btn btn-primary" style="padding:2px 65px 2px 65px;">
						View
						</button></a>
                    </div>
				</div>
					<?php
					
                }  
                } 
            }else{
                echo " There are no results matching your search!";
            }
        
    ?>

</div>