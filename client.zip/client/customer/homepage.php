<?php require 'session.php'; require 'db.php'?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Homepage</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
	<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/homepage-1.css">
	<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fonts.css">
</head>
<body>
    <?php include 'userbar.php'; ?>
    <div class="welcome text-center" id="welcome">
        <h1 id="logo">Audirentur</h1>
        <h3 id="logo" style="font-family: Roboto;">The online rental for sound systems at the best and most affordable price!</h3>
		<?php include'miniSearchBar.html';?>
    </div>
	<div style="background:#E9F3DF;margin:0 10%;box-shadow: 1px 1px 7px 1px rgba(101, 107, 101, 0.8); ">
	  <div class="text-center" style="text-align:center;">
        <br>
        <div style="padding-bottom: 20px;font-family: Roboto; " class="section group text-center">
	        <div class="col span_1_of_5">
                <a href="http://customer.audirentur.com/showProductsCat.php?category=speaker" class="text-dark">
                    <img src="http://customer.audirentur.com/img/boombox.png" style="border-radius:50%;">
                    <br><br>
                    <h3>Speaker</h3>
                </a>
	        </div>
            <div class="col span_1_of_5">
                <a href="http://customer.audirentur.com/showProductsCat.php?category=amplifier" class="text-dark">
                    <img src="http://customer.audirentur.com/img/amplifier.png" style="border-radius:50%;margin-right:190px;">
                    <br><br>
                    <h3>Amplifier</h3>
                </a>
            </div>
            <div class="col span_1_of_5">
                <a href="http://customer.audirentur.com/showProductsCat.php?category=bundle" class="text-dark">
                    <img src="http://customer.audirentur.com/img/sound-system.jpg" style="border-radius:50%;margin-right:190px;">
                    <br><br>
                    <h3>Bundle</h3>
                </a>
            </div>
            <div class="col span_1_of_5">
                <a href="http://customer.audirentur.com/showProductsCat.php?category=equalizer" class="text-dark">
                    <img src="http://customer.audirentur.com/img/equalizer.png" style="border-radius:50%;margin-right:190px;">
                    <br><br>
                    <h3>Equalizer</h3>
                </a>
            </div>
        </div>
    </div>

	<div style="width:100%;float:right;">
	<div>
		<form action="filter-result.php" method="POST" >
		<table width="100%" style="font-family: Roboto;border: 1px solid #DFE1E0;">
			<tr>
			<td width="15%" style="padding: 10px;"><label for="startBudget" style="font-size:30px;">Starting Budget</label></td>
			<td width="15%" style="padding: 10px;"><input type="text" name="startBudget" id="startBudget" placeholder="e.g. 0" style="width:80%;"/></td>
			<td width="15%" style="padding: 10px;"><label for="startBudget" style="font-size:30px;">Ending Budget</label></li></td>
			<td width="15%" style="padding: 10px;"><input type="text" name="endBudget" id="endBudget" placeholder="e.g. 10000" style="width:80%"/></td>
			<td width="10%" style="font-size:30px;">Available&nbsp;</td>
			<td width="15%" style="padding: 10px;"><input type="checkbox" name="available" value="available" id="available" 
						 style="-ms-transform: scale(2);-moz-transform: scale(2);-webkit-transform: scale(2);-o-transform: scale(2);
						 "/>
			</td>
			<td style="text-align:center;"><button type="submit" name="submit-search" class="btn btn-primary" style="padding:10px 25px;">Submit
			</button></td>
			
		</table>
		</form>
	</div>
	</div>
	</div>
	<div width="100%" style="float:left;background:#DFE1E0;margin:auto;" >
		<?php include 'display.php'?>
	</div>
	<br>
    <div id="inside" style="width:100%;float:left;background-color: #292c2f;">
	<?php include 'footer.html'?>
	</div>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>
</html>