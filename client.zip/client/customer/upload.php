<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fonts.css">
<?php include 'db.php';require 'session.php';
		
		$fname = $_FILES["file"]["name"];
        $fsize = $_FILES["file"]["size"];

        $tmp = $_FILES["file"]["tmp_name"];
        $dest = $_SERVER["DOCUMENT_ROOT"] . "/uploads/$fname";

        move_uploaded_file($tmp, $dest);
        
        $image = mysqli_real_escape_string($mysqli, (file_get_contents($_SERVER["DOCUMENT_ROOT"] . "/uploads/$fname")));
		$query = "UPDATE customers SET cust_avatar = '$image' WHERE cust_username = '$user'" ;
             
            if(mysqli_query($mysqli, $query)){
				echo '<script>alert("Succesful")</script>';
				header('Location: /profile.php');
            } else {
                echo "ERROR: Could not able to execute $query. " . mysqli_error($mysqli);
            }
		?>