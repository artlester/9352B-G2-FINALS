<?php include('db.php'); ?>
<?php include 'session.php' ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Filter Results</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/homepage-1.css">
</head>
<body style="background-color:#e3e3e3">
    <?php include 'userbar.php' ?>
    <div style="background:url(./img/heading.jpeg)">
		<center>
		<?php include 'advertisement.html';?><?php echo date_format($availability,"F d, Y");?>
        <div class="container">
            <nav class="nav nav-pills nav-fill">
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=speaker"><h3>Speakers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=equalizer"><h3>Equalizers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=amplifier"><h3>Amplifiers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=bundle"><h3>Bundles</h3></a>
				<h3 class="nav-item" style="width:350px;float:left;padding;"><?php include'miniSearchBar.html';?></h3>
		   </nav>
        </div>
    </div>
    <br>
	<div style="width:90%;margin:auto;">
	<h1>Filter Results:</h1>
    <?php
        error_reporting(0);  
        $available = $_POST['available'];

        if(empty($available)){
            $startBudget = mysqli_real_escape_string($mysqli, $_POST['startBudget']);
            $endBudget = mysqli_real_escape_string($mysqli, $_POST['endBudget']);
            
             $sql = "SELECT 
                        *
                    FROM
                        sounds s
                            LEFT JOIN
                        categories c ON c.category_id = s.category_id
                    WHERE
                          s.price >= '$startBudget' AND s.price <= '$endBudget'
                    ORDER BY s.price";
            
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
    
            echo "<h2>There are " .$queryResults. " results!</h2><br>";
            
            if($queryResults > 0){
                        while($row = mysqli_fetch_assoc($result)){
?>
           	<div class="card-body prod-hover col-md-4" style="width:400px;float:left;text-align:center;height:550px;font-family:Roboto;line-height:5px;">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); padding:3% 1%;">
						<div class="card-img-top">
						<img src="http://audirentur.service.com:3000/uploads/<?php echo $row['product_image']?>"  style="width:210px;height:200px;"/>
						</div>
						<h4 class="card-title"><b><?php echo $row['name']; ?></b></h4><br>
						<div class="info-list-sect">
						<ul class="infos">
						<li>Available:&nbsp;<?php echo $row['date_availability'];?></li>
						<li>Status:&nbsp;<?php echo strtoupper($row['status']); ?></li>
						<li>PHP <?php echo $row['price'];?></li></ul>
						</div>
						<hr>
						<a href="http://customer.audirentur.com/view.php?sound_id=<?php echo $row['sound_id'];?>" style="color:white;"><button class="btn btn-primary" style="padding:2px 65px 2px 65px;">
						View
						</button></a>
                    </div>
				</div>
            <?php 
                 } 
            }
        }else{
        if(isset($_POST['submit-search'])){
                         
            $startBudget = mysqli_real_escape_string($mysqli, $_POST['startBudget']);
            $endBudget = mysqli_real_escape_string($mysqli, $_POST['endBudget']);
            $available = mysqli_real_escape_string($mysqli, $_POST['available']);
            
            $sql = "SELECT 
                        *
                    FROM
                        sounds s
                            LEFT JOIN
                        categories c ON c.category_id = s.category_id
                    WHERE
                          (s.price >= '$startBudget' AND s.price <= '$endBudget') AND (s.status = '$available')
                    ORDER BY s.price";
            
            
            $result = mysqli_query($mysqli, $sql);
            $queryResults = mysqli_num_rows($result);
            
    
            echo "<h2>There are " .$queryResults. " results!</h2><br>";
            
            if($queryResults > 0){
                        while($row = mysqli_fetch_assoc($result)){
                            ?>
            <div class="card-body" style="width:400px;float:left;text-align:center;">
					<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); padding:3% 1%;">
						<div class="card-img-top">
							<img src="http://audirentur.service.com:3000/uploads/<?php echo $product['product_image']?>"  style="width:210px;height:200px;"/>
						</div>
						<h4 class="card-title"><?php echo $row["name"]; ?></h4><br>
						<h5 class="card-subtitle"><?php echo date_format($availability,"F d, Y");?></h5><br>
						<h6 class="card-subtitle">Status:&nbsp;<i><?php echo strtoupper($row['status'])?>
						<a href="http://customer.audirentur.com/view.php?sound_id=<?php echo $row['sound_id'];?>" style="color:white;"><button class="btn btn-primary" style="padding:2px 65px 2px 65px;">
						View Profile
						</button></a>
                    </div>
				</form>
				</div>
            <?php 
                        } 
                    }
            }
        }
    ?>
</div>
<footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>