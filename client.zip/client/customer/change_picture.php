<?php  
require ('session.php');
include ('db.php');  
?>
<html>
   
   <head>
	<meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Edit Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">

   </head>
   
   <body style="margin:0;background:#D3D3D3;">
       <?php include 'userbar.php' ?>
       <div style="background: #a8ff78;  /* fallback for old browsers */
        background: -webkit-linear-gradient(to right, #78ffd6, #a8ff78);  /* Chrome 10-25, Safari 5.1-6 */
                   background: linear-gradient(to right, #78ffd6, #a8ff78); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */"id="grad-bg"></div>
       <div>
	   </div>
       <div style=" border: 1px solid black;  width: 450px; position:relative; margin: 0 auto; padding: 15px; margin-top: 80px; box-shadow: 0 0 20px #000;">
       <p style="font-size:50px; text-align:center;">Update Profile Picture</p>
	   
        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <label>Select image:</label> 
			<input type="file" name="file" style="background-color: #4CAF50;
                    color: white;
                    padding: 14px 20px;
                    margin: 0 auto;
                    position:relative;  
                    display:block;
                    cursor: pointer;
                    width: 280px;
                    opacity: 0.9;  "></p>
            <center>
			<table>
			<tr>
			<td><input type="submit" value="Upload File" style="background-color: #4CAF50;
                    color: white;
					padding: 14px 20px;
                    margin: 0 auto;
                    margin-top:20px;
                    position:relative;  
                    display:block;
                    cursor: pointer;
                    width: 150px;
					opacity: 0.9;"></td>
			<td><a href="http://customer.audirentur.com/profile.php" style="background-color: red;
                    color: white;
                    padding: 14px 20px;
                    margin: 0 auto;
                    margin-top:20px;
                    position:relative;  
                    display:block;
                    cursor: pointer;
                    width: 95px;
                    text-align:center;
                 opacity: 0.9;">Cancel</a></td>
			</tr>
			</table>
			</center>
        </form>
        <hr>
   </body>
</html>