<?php require 'session.php'; require 'db.php'?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Vendor</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
	<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/homepage-1.css">
</head>
<body style="background-color:#e3e3e3;">
    <?php include 'userbar.php' ?>
    <div style="background:url(./img/heading.jpeg)">
		<center>
		<?php include 'advertisement.html';?>
		</center>
    </div>
    <div class="container-fluid bg-black" id="bg-black">
        <div >
            <nav class="nav nav-pills nav-fill">
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=speaker"><h3>Speakers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=equalizer"><h3>Equalizers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=amplifier"><h3>Amplifiers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=bundle"><h3>Bundles</h3></a>
				<h3 class="nav-item" style="width:350px;float:left;padding;"><?php include'miniSearchBar.html';?></h3>
			</nav>
        </div>
    </div>
<?php
$vendor_id = $_GET['vendor_id'];

$sql = "SELECT * FROM vendors WHERE vendors.vendor_id='$vendor_id'";
$result = mysqli_query($mysqli, $sql);
while($row = mysqli_fetch_array($result)){
?>
<div style="width:100%;height:500px;padding-top:20px;margin-left:15%;margin-top:2%;" class="container">
			
			<div style="padding: 30px;width:80%;float:left;text-align:center;font-family:Roboto;background-color:#1B211C;color:white;border: 7px solid rgba(231, 238, 232, 0.8); border-radius: 10px;" >
			<div style="width:30%;float:left;text-align:center;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);float:left;display:inline-block;">
			<?php 
			if(empty($row['ven_avatar'])) {
                    if($row['ven_gender'] == "Male") {
                        echo '<img src="img/default_avatar_male.jpg" id="profile-picture" width="300px" height="auto">';
                    } else {
                        echo '<img src="img/default_avatar_female.jpg" id="profile-picture" width="300px" height="auto">';
                    }
                } else {
				echo '<img src="data:img/jpg;base64,'.base64_encode( $row['ven_avatar']).'" style="width:50px;height:50px;"/>';
                }
			?>
			</div>
			<div style="float:left;display:inline-block;width:60%; background-color:rgba(226, 232, 226 , 0.4);margin-left:10%;">
			<ul style="list-style:none;text-align:left;font-size:20px;">
			<li style="font-size:100px;"><?php echo $row["ven_username"]; ?></li>
			<ul style="list-style: none;">
			<li style="font-size: 20px;">
			<b>Contact:&nbsp;</b>
			<ul style="list-style: none;">
			<li><?php echo $row['ven_contact_number']?></li>
			<li><?php echo $row["ven_email"];?></p></li></li>
			</ul></ul><br></ul>
			</div>
            </div>
</div>
<div style="width:95%;margin:auto;">
<div style="width:95%;margin:auto;margin-top:-5%;">	
<?php
}
$query = "SELECT * FROM sounds NATURAL JOIN vendors WHERE vendors.vendor_id='$vendor_id'";
			
            $result = mysqli_query($mysqli, $query);
	
        while ($product = mysqli_fetch_assoc($result)){
			$availability=date_create($product['date_availability']);
?>
				<div class="card-body prod-hover col-md-4" style="width:400px;float:left;text-align:center;height:550px;font-family:Roboto;line-height:5px;">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); padding:3% 1%;">
						<div class="card-img-top">
						<img src="http://audirentur.service.com:3000/uploads/<?php echo $product['product_image']?>"  style="width:210px;height:200px;"/>
						</div>
						<h4 class="card-title"><b><?php echo $product['name']; ?></b></h4><br>
						<div class="info-list-sect">
						<ul class="infos">
						<li>Available:&nbsp;<?php echo date_format($availability,"F d,Y");?></li>
						<li>Status:&nbsp;<?php echo strtoupper($product['status']); ?></li>
						<li>PHP <?php echo $product['price'];?></li></ul>
						</div>
						<hr>
						<a href="http://customer.audirentur.com/view.php?sound_id=<?php echo $product['sound_id'];?>" style="color:white;"><button class="btn btn-primary" style="padding:2px 65px 2px 65px;">
						View
						</button></a>
                    </div>
				</div>
<?php 
}
?>
</div>
</div>
 <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>