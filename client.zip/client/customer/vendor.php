<?php require 'session.php'; require 'db.php'?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: Vendor</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
	<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/homepage-1.css">
</head>
<body style="background-color:#e3e3e3;">
    <?php include 'userbar.php' ?>
    <div style="background:url(./img/heading.jpeg)">
		<center>
		<?php include 'advertisement.html';?>
		</center>
    </div>
    <div class="container-fluid bg-black" id="bg-black">
        <div >
            <nav class="nav nav-pills nav-fill">
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=speaker"><h3>Speakers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=equalizer"><h3>Equalizers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=amplifier"><h3>Amplifiers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=bundle"><h3>Bundles</h3></a>
				<h3 class="nav-item" style="width:350px;float:left;padding;"><?php include'miniSearchBar.html';?></h3>
			</nav>
        </div>
    </div>
<?php
$vendor_id = $_POST['vendor_id'];
$sql = "SELECT * FROM vendors WHERE vendors.vendor_id='$vendor_id'";
$result = mysqli_query($mysqli, $sql);
while($row = mysqli_fetch_array($result)){
?>
<div style="width:100%;height:500px;padding-top:20px;" class="container">
			<div style="width:20%;float:left;text-align:center;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
			<?php 
			if(empty($row['ven_avatar'])) {
                    if($row['ven_gender'] == "Male") {
                        echo '<img src="img/default_avatar_male.jpg" id="profile-picture" width="300px" height="auto">';
                    } else {
                        echo '<img src="img/default_avatar_female.jpg" id="profile-picture" width="300px" height="auto">';
                    }
                } else {
				echo '<img src="data:img/jpg;base64,'.base64_encode( $row['ven_avatar']).'" style="width:50px;height:50px;"/>';
                }
			?>
			</div>
			<div style="width:80%;float:left;text-align:center;font-family:RenaultBQ-Light;" >
			<h1 style="font-size:140px;"><?php echo $row["ven_username"]; ?></h4><br>
			<h2><?php echo $row["ven_first_name"]."&nbsp;".$row["ven_last_name"];?></h4><br>
			<h3><?php echo $row["ven_email"];?></h5><br>
			<h3><?php echo $row['ven_contact_number']; ?></h6><br>
            </div>
</div>
<div style="margin:0 200px;">
<div>	
<?php
}
$query = "SELECT * FROM sounds NATURAL JOIN vendors WHERE vendors.vendor_id='$vendor_id'";
			
            $result = mysqli_query($mysqli, $query);
	
        while ($product = mysqli_fetch_assoc($result)){

?>
			<div class="card-body card-hover" style="width:400px;float:left;text-align:center;height:550px;" >
				<form action="http://customer.audirentur.com/view.php" method="post">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); padding:3% 1%;">
						<div class="card-img-top">
						<?php echo '<img src="data:img/jpg;base64,'.base64_encode( $product['product_image']).'" style="width:210px;height:200px;"/>'?>
							<!--img src="http://audirentur.service.com:3000/uploads/<?php echo $product['product_image']?>" 
							style="width:210px;height:200px;"/-->
						</div>
						<h4 class="card-title"><?php echo $product['name']; ?></h4><br>
						<h4 class="card-subtitle">Duration:&nbsp;<?php echo $product['duration']; ?>&nbsp;days</h4><br>
						<h5 class="card-subtitle">Available:&nbsp;<?php echo $product['date_availability'];?></h5><br>
						<h6 class="card-subtitle">Status:&nbsp;<i><?php echo strtoupper($product['status']); ?></i></h6><br>
						<h5 class="card-subtitle">Price: PHP <?php echo $product['price'];?></h5><br>
						<input name="sound_id" type="hidden" value="<?php echo $product['sound_id'];?>"/>
						<input type="submit" name="view-details" value="VIEW" class="btn btn-primary" style="padding:2px 65px 2px 65px"/>
                    </div>
				</form>
			</div>		
<?php 
}
?>
</div>
</div>
 <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>