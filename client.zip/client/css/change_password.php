<?php  
require ('session.php');
require ('db.php');  
?>
<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/edit_profile.css">
<html>
   
   <head>
      
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Edit Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/userbar.css">
   </head>
   
   <body style="margin:0;background: #fc00ff;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #00dbde, #fc00ff);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #00dbde, #fc00ff); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
">
       <?php include 'userbar.php' ?>
       <div style="background: #a8ff78;  /* fallback for old browsers */
        background: -webkit-linear-gradient(to right, #78ffd6, #a8ff78);  /* Chrome 10-25, Safari 5.1-6 */
                   background: linear-gradient(to right, #78ffd6, #a8ff78); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */"id="grad-bg"></div>
       <div>
	   <center>
				<a href="http://customer.audirentur.com/profile.php" style="color:black;">
				<h1><i class="fa fa-arrow-left"></i>&nbsp;Go Back</h1></a>
				</center>
	   </div>
	   <div style=" border: 1px solid black; width: 450px; position:relative; margin: 0 auto; padding: 15px; margin-top: 100px; box-shadow: 0 0 20px #000;">
       <p style="font-size:50px; text-align:center;">Change Password</p>
       
            <form method = "post" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-style-9" >
               
                <input name = "old_pass" type = "password" id = "old_pass" placeholder="Old Password" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
                <br>
                <input name = "new_pass" type = "text" id = "new_pass" placeholder="New Password" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
             
                <br>
                <input name = "retype_pass" type = "text" id = "retype_pass" placeholder="Re-type Password" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
                     
               <br>
                <br>
                <button type="text" name="update" class="hover-button" style="background-color: #4CAF50;
                    color: white;
                    padding: 14px 20px;
                    margin: 0 auto;
                    position:relative;  
                    display:block;
                    cursor: pointer;
                    width: 280px;
                    opacity: 0.9;">Submit</button>
        
     </form>
    </div>
         <?php
       if($_SESSION['username']){
         if(isset($_POST['update'])) {
               
             $cust_id = $_SESSION['customer_id'];
             $newusername = $_SESSION['username'];
             $typed_password = ($_POST['old_pass']);
             $newpassword = ($_POST['new_pass']);
             $retype_password = ($_POST['retype_pass']);

            
               
            // Attempt update query execution
            /*$query = "UPDATE customers ". "SET cust_password = '$newpassword'". 
               "WHERE customer_id = $cust_id" ;*/
             $result = $mysqli->query("SELECT cust_password FROM customers WHERE customer_id = $cust_id");
             $row = $result->fetch_assoc();
             
             
                ob_start();
                echo ($row['cust_password']);
                $oldpassworddb = ob_get_contents(); 
                ob_end_clean();

             //echo "$oldpassworddb/$typed_password";
             
             if($oldpassworddb==$typed_password){
                 if($newpassword==$retype_password){
                     
                $query = "UPDATE customers ". "SET cust_password = '$newpassword'". 
                         "WHERE customer_id = $cust_id" ;
                     
                    if(mysqli_query($mysqli, $query)){
                        echo '<script>alert("Password changed. You need to Log-in.")</script>';
                        session_destroy(); 
                        mysqli_close($mysqli);
                    } else {
                        echo "ERROR: Could not able to execute $query. " . mysqli_error($mysqli);
                    }
                     
                 }else{
                     die("New passwords don't match.");
                 }
                 
             }else{
                 die("Old password doesn't match.");
             }
         }
             
            /*if(mysqli_query($mysqli, $query)){
                echo "Password changed successfully."; 
               
                session_destroy(); 
                mysqli_close($mysqli);
            } else {
                echo "ERROR: Could not able to execute $query. " . mysqli_error($mysqli);
            }
            
            
         }*/
       }
      ?>
     
   </body>
</html>