<?php  
require ('session.php');
include ('db.php');  
?>
<html>
   
   <head>
      
      
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Edit Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/userbar.css">

   </head>
   
   <body style="margin:0;background: #fc00ff;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #00dbde, #fc00ff);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #00dbde, #fc00ff); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
">
       <?php include 'userbar.php' ?>
       <div style="background: #a8ff78;  /* fallback for old browsers */
        background: -webkit-linear-gradient(to right, #78ffd6, #a8ff78);  /* Chrome 10-25, Safari 5.1-6 */
                   background: linear-gradient(to right, #78ffd6, #a8ff78); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */"id="grad-bg"></div>
       <div>
	   <center>
				<a href="http://customer.audirentur.com/profile.php" style="color:black;">
				<h1><i class="fa fa-arrow-left"></i>&nbsp;Go Back</h1></a>
				</center>
	   </div>
       <div style=" border: 1px solid black;  width: 450px; position:relative; margin: 0 auto; padding: 15px; margin-top: 80px; box-shadow: 0 0 20px #000;">
       <p style="font-size:50px; text-align:center;">Update Profile</p>
       
       
      <form method = "post" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-style-9">
               
                 
                <input name = "firstname" type = "text" id = "firstname" placeholder="Firstname" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
             
                    <br>
					
				 <input name = "lastname" type = "text" id = "lastname" placeholder="Lastname" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
             
                    <br>
					
				<input name = "username" type = "text" id = "username" placeholder="Username" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
             
                    <br>
                 
                <input name = "gender" type = "text" id = "gender" placeholder="Gender" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
             
                    <br>
                 
                <input name = "contact" type = "text" id = "contact" placeholder="Contact Number" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
             
                    <br>
                 
                <input name = "email" type = "text" id = "email" placeholder="Email" style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required> 
             
                    <br>
                    
                
               <textarea name="bio" class="field-style" placeholder="About Me..." style="width: 350px;
                    padding: 15px;
                    margin: 0 auto;
                    position:relative;
					display:block;
                    border: 3px solid #555;
                    background: #f1f1f1; " required></textarea>
          
                    <br>           
                    <br>
					<br>
                <button type="text" name="update" class="hover-button" style="background-color: #4CAF50;
                    color: white;
                    padding: 14px 20px;
                    margin: 0 auto;
                    position:relative;  
                    display:block;
                    cursor: pointer;
                    width: 280px;
                    opacity: 0.9;  ">Update</button>
        
     </form>
       </div>
            <?php
       
         if(isset($_POST['update'])) {
             
             $cust_id = $_SESSION['customer_id'];
			 $newfirstname = $_POST['firstname'];
			 $newlastname = $_POST['lastname'];
             $newusername = $_POST['username'];
             $newbio = $_POST['bio'];
             $newgender = $_POST['gender'];
             $newcontact = $_POST['contact'];
             $newemail = $_POST['email'];
                     
            
             
             if($mysqli === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }

            // Attempt update query execution
            $query = "UPDATE customers SET cust_username = '$newusername',cust_first_name = '$newfirstname',cust_last_name = '$newlastname',
			cust_bio = '$newbio', cust_gender = '$newgender', cust_contact_number = '$newcontact', cust_email = '$newemail' WHERE customer_id = $cust_id" ;
             
            if(mysqli_query($mysqli, $query)){
                echo '<script>alert("Records were updated successfully.You need to Log-in.")</script>'; 
                
            } else {
                echo "ERROR: Could not able to execute $query. " . mysqli_error($mysqli);
            }

         }
      ?>
      
   </body>
</html>