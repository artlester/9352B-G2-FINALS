<?php require 'db.php';require 'session.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Audirentur: View</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="http://customer.audirentur.com/img/logo.png" />
    <!--CSS-->
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/products.css">
	<link rel="stylesheet" type="text/css" href="http://customer.audirentur.com/css/fonts.css">
	<style>
		.prod-img {
		border: 10px solid rgba(194, 198, 195, 0.6);
		border-radius: 7px;
	}
	
	.info-div {
		background-color: white; 
		padding: 20px;
		border-radius:5px;
		border: 10px solid #C2C6C3;
	}
	</style>
</head>
</head>
<body style="background-color:#e3e3e3">
    <?php include 'userbar.php' ?>
    <div style="background:url(./img/heading.jpeg)">
		<center>
		<?php include 'advertisement.html';?>
		</center>
    </div>
    <div class="container-fluid bg-black" id="bg-black">
        <div class="container">
            <nav class="nav nav-pills nav-fill">
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=speaker"><h3>Speakers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=equalizer"><h3>Equalizers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=amplifier"><h3>Amplifiers</h3></a>
                <a class="nav-item nav-link text-light" href="http://customer.audirentur.com/showProductsCat.php?category=bundle"><h3>Bundles</h3></a>
				<h3 class="nav-item" style="width:350px;float:left;padding;"><?php include'miniSearchBar.html';?></h3>
			</nav>
        </div>
    </div>
    <br>
	<div>
<?php
$sound_id=$_POST['sound_id'];

if(isset($_POST['view-details'])){
			$query = "SELECT * FROM sounds NATURAL JOIN vendors WHERE sounds.sound_id='$sound_id'";
			
            $result = mysqli_query($mysqli, $query);
        while ($row = mysqli_fetch_assoc($result)){
			$_SESSION['sound_id']=$row['sound_id'];
			$availability=date_create($row['date_availability']);
			?> 			
		<div style="width:40%;height:500px;float:left;text-align:center;background:white;margin:0 40px; padding: 40px 10px 10px 10px;" class="prod-img">
		<img src="http://audirentur.service.com:3000/uploads/<?php echo $row['product_image']?>" 
		style="width:25vw;overflow:auto;vertical-align:center;"/>
		</div>
		<div style="width:50%;float:left;padding: 30px;font-family:RenaultBQ-Light;border:1px groove;" class="info-div">
		<form action="http://customer.audirentur.com/rent.php" method="post">

			<h1><b><?php echo $row['name']; ?></b></h1>
			<ul style="list-style:none; font-size: 25px;">
			<li><b>Price:</b>&nbsp;Php&nbsp;<?php echo $row['price']?>.00</li>
			<li><b>Available:</b>&nbsp;<?php echo date_format($availability,"F d,Y");?></li>
			<li><b>Status:&nbsp;</b><b><?php echo strtoupper($row['status']); ?></b></li>
			<br>
			<li><b>Description:</b>&nbsp;<p style="font-size:20px;text-align:left;margin-right:30px;"><?php echo $row['description']?><p></li>
			</ul>
			<input name="sound_id" type="hidden" value="<?php echo $row['sound_id'];?>"/>
			<input type="submit" name="rent" value="RENT" class="btn btn-primary" style="padding:6px 30px 6px 30px;width:100%;margin:auto;margin-top:10px;border-radius:5px;"/>
        </form>
		<hr>
		<form action="http://customer.audirentur.com/vendor.php" method="post">
			<h3><b>Vendor Name:</b>&nbsp;<?php echo $row['ven_username']?></h3>
			<ul style="list-style: none;">
			<li style="font-size: 20px;">
			<b>Contact:&nbsp;</b>
			<ul style="list-style: none;">
			<li><?php echo $row['ven_contact_number']?></li>
			<li><?php echo $row["ven_email"];?></p></li></li>
			</ul></ul><br>
			<input name="vendor_id" type="hidden" value="<?php echo $row['vendor_id'];?>"/>
			<input type="submit" name="view" value="View Profile" class="btn btn-primary" style="padding:6px 30px 6px 30px;width:100%;margin:auto;margin-top:10px;border-radius:5px;"/>
			</form>
		</div>
<?php			
		}
}
?>
</div>
</div>


	
    <footer>
        <span>© Copyright 2018 Audirentur</span>
    </footer>
    <!--JAVASCRIPT-->
    <script src="http://customer.audirentur.com/js/jquery-3.3.1.js"></script>
    <script src="http://customer.audirentur.com/js/bootstrap.min.js"></script>
</body>