<?php
$sql ="SELECT sound_id, name, duration, status, product_image,price, DATE_FORMAT(date_availability, '%M %d,%Y')as 
		 date_availability FROM sounds WHERE (NOT status = 'permanently unavailable') AND
		 (date_availability > DATE_SUB(NOW(), INTERVAL 1 WEEK)) ORDER BY sound_id DESC";
		 
		 $result=mysqli_query($mysqli,$sql);
               $queryResults=mysqli_num_rows($result);
			   if($queryResults > 0){
						
			?>
			<div>
			<?php
                while($product = mysqli_fetch_array($result)){
					$_SESSION['sound_id']=$product['sound_id'];
            ?>
			<div class="card-body card-hover" style="width:400px;float:left;text-align:center;height:550px;font-family:Verdana;line-height:5px;">
				<form action="http://customer.audirentur.com/view.php" method="post">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); padding:3% 1%;">
						<h4 style="line-height:0;"><i>NEW!</i></h4>
						<hr>
						<div class="card-img-top">
						<img src="http://audirentur.service.com:3000/uploads/<?php echo $product['product_image']?>"  style="width:210px;height:200px;"/>
						</div>
						<h4 class="card-title"><?php echo $product['name']; ?></h4><br>
						<h5 class="card-subtitle">Available:&nbsp;<?php echo $product['date_availability'];?></h5><br>
						<h6 class="card-subtitle">Status:&nbsp;<i><?php echo strtoupper($product['status']); ?></i></h6><br>
						<h5 class="card-subtitle">PHP <?php echo $product['price'];?></h5><br>
						<input name="sound_id" type="hidden" value="<?php echo $product['sound_id'];?>"/>
						<input type="submit" name="view-details" value="VIEW" class="btn btn-primary" style="padding:2px 65px 2px 65px;"/>
                    </div>
				</form>
				</div>
				<?php
						}
			   }	
						?>
			</div>
<?php	
		 $sql ="SELECT sound_id, name, status, product_image,price, DATE_FORMAT(date_availability, '%M %d,%Y')as 
		 date_availability FROM sounds WHERE (NOT status ='permanently unavailable') AND (NOT date_availability > DATE_SUB(NOW(), INTERVAL 1 WEEK)) ORDER BY sound_id DESC";
		 
		 $result=mysqli_query($mysqli,$sql);
               $queryResults=mysqli_num_rows($result);
                    if($queryResults > 0){
						
			?>
			<div>
			<?php
                while($product = mysqli_fetch_array($result)){
					$_SESSION['sound_id']=$product['sound_id'];
            ?>
			<div class="card-body card-hover" style="width:400px;float:left;text-align:center;height:550px;font-family:Verdana;line-height:5px;">
				<form action="http://customer.audirentur.com/view.php" method="post">
				<div style="background-color:white;border-radius:15px;
				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); padding:3% 1%;">
						<div class="card-img-top">
						<img src="http://audirentur.service.com:3000/uploads/<?php echo $product['product_image']?>"  style="width:210px;height:200px;"/>
						</div>
						<h4 class="card-title"><?php echo $product['name']; ?></h4><br>
						<h5 class="card-subtitle">Available:&nbsp;<?php echo $product['date_availability'];?></h5><br>
						<h6 class="card-subtitle">Status:&nbsp;<i><?php echo strtoupper($product['status']); ?></i></h6><br>
						<h5 class="card-subtitle">PHP <?php echo $product['price'];?></h5><br>
						<input name="sound_id" type="hidden" value="<?php echo $product['sound_id'];?>"/>
						<input type="submit" name="view-details" value="VIEW" class="btn btn-primary" style="padding:2px 65px 2px 65px;"/>
                    </div>
				</form>
				</div>
				<?php
						}
						
						?>
			</div>
				<?php
                    }
					?>
				
				