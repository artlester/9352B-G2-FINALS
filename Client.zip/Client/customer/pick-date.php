<div>
		<div>
		<form method="post" style="text-align:center">
		<table>
			<tr>
			<td><input type="submit" name="t-trans" value="TODAY" style="font-size:15px;"class="btn btn-primary"/></td>
			<td><input type="submit" name="mon-trans" value="MONTH" style="font-size:15px;"class="btn btn-primary"/></td>
			<td><input type="submit" name="filt-trans" value="FIND" style="font-size:20px;" class="btn btn-primary"/></td>
			<td><input type="submit" name="rentals-trans" value="Receipt" style="font-size:15px;" class="btn btn-primary"/></td>
			
			</tr>
		</table>
		</form>
		</div>
		<hr>
	<div style="overflow-y:scroll;height:50em;padding-bottom:100px;">
		<?php
		if(isset($_POST['t-trans'])){
			$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
							DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name 
							FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
							INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
								WHERE customers.cust_username= '$user' AND Date(rental_date) = Date(NOW())";
						$result = mysqli_query($mysqli, $query);
						$queryresults = mysqli_num_rows($result);
						if ($queryresults !=0){
						$no=1;
						while ($row = mysqli_fetch_array($result)){
							echo '<hr><form style="background-color:whitesmoke;padding:10px;">
									
									<h3>'.$row['name'].'</h3>
									<p><b>Rental Date: </b>'.$row['rental_date'].'</p>
									<p><b>Return Date: </b>'.$row['return_date'].'</p>
									<p><b>Status: </b>'.$row['status'].'</p>
									
									</form>';
								$no++;
						}
						}else{
						echo '<h1 style="font-size:90px;font-family:UrbanJungleDEMO;text-align:center;">NONE</h1>';
						}
		}
		if(isset($_POST['mon-trans'])){
			$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
							DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name 
							FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
							INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
								WHERE customers.cust_username= '$user' AND rentals.rental_date > DATE_SUB(NOW(), INTERVAL 1 MONTH);";
						$result = mysqli_query($mysqli, $query);
						$queryresults = mysqli_num_rows($result);
						if ($queryresults !=0){
						$no=1;
						while ($row = mysqli_fetch_array($result)){
							echo '<hr><form style="background-color:whitesmoke;padding:10px;">
									
									<h3>'.$row['name'].'</h3>
									<p><b>Rental Date: </b>'.$row['rental_date'].'</p>
									<p><b>Return Date: </b>'.$row['return_date'].'</p>
									<p><b>Status: </b>'.$row['status'].'</p>
									
									</form>';
								$no++;
						}
						}else{
						echo '<hr><h1 style="font-size:30px;font-family:The Bully;text-align:center;">NONE</h1>';
						}
		}
			?>
			<?php
			if(isset($_POST['filt-trans'])){
				echo '
			<div style="width:100%">
				<form method="post" action="'.$_SERVER['PHP_SELF'].'">
					<h2>Choose Date!</h2>
					<div class="container input-group">
						<input type="date" style="font-size:25px;width:30%;" name="rental_date" class="form-control py-2"/>
						<div class="input-group-append">
						<input type="submit" name="pickdate" style="padding:0 25px 0 25px"/>
						</div>
					</div>
				</form>';
			}
if(isset($_POST['pickdate'])){
				$rental_date=$_POST['rental_date'];
					$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
							DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name 
							FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id) 
							INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
								WHERE customers.cust_username= '$user' AND rentals.rental_date= '$rental_date'";
						$result = mysqli_query($mysqli, $query);
						
						$queryresults = mysqli_num_rows($result);
			?>
			<div>
				<h2>Date:&nbsp;<?php echo $rental_date;?></h2>
				</div>
					
				<?php 
				
						if ($queryresults !=0){
						$no=1;
						while ($row = mysqli_fetch_array($result)){
							echo '<form style="background-color:powderblue;width:300px;" >
									
									<h3>'.$row['name'].'</h3>
									<p><b>Rental Date: </b>'.$row['rental_date'].'</p>
									<p><b>Return Date: </b>'.$row['return_date'].'</p>
									<p><b>Status: </b>'.$row['status'].'</p>
									
									</form>';
								$no++;
						}
						}else{
						echo '<br><p style="font-size:30px;">No Rental Activities...</p>';
						}
				
				}			
				?>
				<?php
			if(isset($_POST['rentals-trans'])){
				$query = "SELECT rentals.rental_id, DATE_FORMAT(rentals.rental_date, '%Y,%M %d')as rental_date,
							DATE_FORMAT(rentals.return_date, '%Y,%M %d')as return_date , rentals.status, sounds.name, 
							rentals.amount_payable, vendors.ven_username
							FROM ((customers INNER JOIN rentals on customers.customer_id=rentals.customer_id)
							INNER JOIN sounds on rentals.sound_id=sounds.sound_id)
							INNER JOIN vendors on sounds.vendor_id=vendors.vendor_id
								WHERE customers.cust_username= '$user' AND rentals.status='finished'";
						$result = mysqli_query($mysqli, $query);
						$queryresults = mysqli_num_rows($result);
						if ($queryresults !=0){
						$no=1;
						while ($row = mysqli_fetch_array($result)){
							echo '<hr><form style="background-color:whitesmoke;padding:10px;">
									
									<h3>'.$row['name'].'</h3>
									<p><b>Rental Date: </b>'.$row['rental_date'].'</p>
									<p><b>Return Date: </b>'.$row['return_date'].'</p>
									<p><b>Amount Paid:&nbsp;</b>Php&nbsp;'.$row['amount_payable'].'</p>
									<p><b>Vendor Name: </b>'.$row['ven_username'].'</p>
									<p><b>Status: </b>'.$row['status'].'</p>
									
									</form>';
								$no++;
						}
						}else{
						echo '<h1 style="font-size:90px;font-family:UrbanJungleDEMO;text-align:center;">NONE</h1>';
						}
				
				}			
				?>
		</div>
	</div>	
</div>