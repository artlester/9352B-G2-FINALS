<?php include 'session.php' ?>
<?php include('db.php'); ?>


    <html>
    <body>
    
    <h1>Equalizer</h1>
    
        <div class="results-container">
            <?php
            
                $category = mysqli_real_escape_string($mysqli, $_GET['category']);  
            
               $sql ="SELECT 
                        *
                    FROM
                        sounds s
                            JOIN
                        categorysound cs ON s.sound_id = cs.sound_id
                            JOIN
                        categories c ON c.category_id = cs.category_id
                    WHERE
                        category = 'equalizer'";
            
               $result=mysqli_query($mysqli,$sql);
               $queryResults=mysqli_num_rows($result);
                
                    if($queryResults > 0){
                        while($row = mysqli_fetch_assoc($result)){
                            ?>
            
            <form style="width:500px;float:left;padding:10px;font-size:30px;">
					<div style="border:1px solid #333; border-radius:5px; padding:10px; " align="center">
					<img src="http://audirentur.service.com:3000/uploads/<?php echo $row['product_image']?>" 
					style="width:400px;height:300px;"/>
					<br />
						<h2><?php echo $row['name']; ?></h2>
                        <b>Available: <?php echo $row['date_availability'];?>
				        </b>
                        <p>Status: <?php echo$row['status']; ?></p>
                                    
                    </div>
				</form>
            
            <?php 
                        } 
                    }
                ?>
            </div>
</body>
    </html>
    