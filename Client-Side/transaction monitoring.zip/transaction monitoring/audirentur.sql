-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 16, 2018 at 12:35 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `audirentur`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int(11) NOT NULL,
  `category` varchar(20) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categorysound`
--

DROP TABLE IF EXISTS `categorysound`;
CREATE TABLE IF NOT EXISTS `categorysound` (
  `sound_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`sound_id`,`category_id`),
  KEY `fk_sounds_has_categories_categories1_idx` (`category_id`),
  KEY `fk_sounds_has_categories_sounds1_idx` (`sound_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `customer_id` int(11) NOT NULL,
  `cust_username` varchar(64) NOT NULL,
  `cust_password` varchar(120) NOT NULL,
  `cust_last_name` varchar(35) NOT NULL,
  `cust_first_name` varchar(35) NOT NULL,
  `cust_gender` enum('Male','Female') NOT NULL,
  `cust_email` varchar(254) NOT NULL,
  `cust_contact_number` varchar(15) NOT NULL,
  `cust_avatar` longblob,
  `cust_bio` varchar(125) DEFAULT NULL,
  `cust_create_date` datetime NOT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `reg_id_UNIQUE` (`customer_id`),
  UNIQUE KEY `username_UNIQUE` (`cust_username`),
  UNIQUE KEY `email_UNIQUE` (`cust_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `cust_username`, `cust_password`, `cust_last_name`, `cust_first_name`, `cust_gender`, `cust_email`, `cust_contact_number`, `cust_avatar`, `cust_bio`, `cust_create_date`) VALUES
(1, 'Sherlea', 'SHerlea', 'Carlines', 'Sheylea', 'Female', 'sherlea@gmail.com', '0923678990', NULL, NULL, '2018-05-16 04:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

DROP TABLE IF EXISTS `registrations`;
CREATE TABLE IF NOT EXISTS `registrations` (
  `reg_id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(120) NOT NULL,
  `last_name` varchar(35) NOT NULL,
  `first_name` varchar(35) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `email` varchar(254) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `accountType` enum('Customer','Service Provider') NOT NULL,
  `status` enum('Pending','Accepted','Denied') NOT NULL,
  PRIMARY KEY (`reg_id`),
  UNIQUE KEY `reg_id_UNIQUE` (`reg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

DROP TABLE IF EXISTS `rentals`;
CREATE TABLE IF NOT EXISTS `rentals` (
  `rental_id` int(11) NOT NULL,
  `rental_date` datetime NOT NULL,
  `return_date` datetime DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `sound_id` int(11) NOT NULL,
  `status` enum('Pending','Renting','Rented','Cancelled') NOT NULL,
  PRIMARY KEY (`rental_id`),
  UNIQUE KEY `rental_id_UNIQUE` (`rental_id`),
  KEY `fk_rentals_customers_idx` (`customer_id`),
  KEY `fk_rentals_vendors1_idx` (`vendor_id`),
  KEY `fk_rentals_sounds1_idx` (`sound_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`rental_id`, `rental_date`, `return_date`, `customer_id`, `vendor_id`, `sound_id`, `status`) VALUES
(1, '2018-05-09 12:00:00', '2018-08-16 13:00:00', 1, 1, 1, 'Rented'),
(2, '2018-05-16 07:00:00', '2018-05-24 00:00:00', 1, 1, 2, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `sounds`
--

DROP TABLE IF EXISTS `sounds`;
CREATE TABLE IF NOT EXISTS `sounds` (
  `sound_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `duration` int(11) NOT NULL,
  `price` double NOT NULL,
  `replacement_cost` double DEFAULT NULL,
  PRIMARY KEY (`sound_id`),
  UNIQUE KEY `sound_id_UNIQUE` (`sound_id`),
  KEY `fk_sounds_vendors1_idx` (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sounds`
--

INSERT INTO `sounds` (`sound_id`, `vendor_id`, `name`, `description`, `duration`, `price`, `replacement_cost`) VALUES
(1, 1, 'Bluetooth Speaker', 'New\r\nNever use', 24, 567, 234),
(2, 1, 'Home Theater System', 'Used once', 67, 4567, 3000);

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

DROP TABLE IF EXISTS `vendors`;
CREATE TABLE IF NOT EXISTS `vendors` (
  `vendor_id` int(11) NOT NULL,
  `ven_username` varchar(64) NOT NULL,
  `ven_password` varchar(120) NOT NULL,
  `ven_last_name` varchar(35) NOT NULL,
  `ven_first_name` varchar(35) NOT NULL,
  `ven_gender` enum('Male','Female') NOT NULL,
  `ven_email` varchar(254) NOT NULL,
  `ven_contact_number` varchar(15) NOT NULL,
  `ven_avatar` longblob,
  `ven_bio` varchar(125) DEFAULT NULL,
  `ven_create_date` datetime NOT NULL,
  PRIMARY KEY (`vendor_id`),
  UNIQUE KEY `vendor_id_UNIQUE` (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`vendor_id`, `ven_username`, `ven_password`, `ven_last_name`, `ven_first_name`, `ven_gender`, `ven_email`, `ven_contact_number`, `ven_avatar`, `ven_bio`, `ven_create_date`) VALUES
(1, 'Henry', 'Henry', 'Lamine', 'Henry', 'Male', 'henrylamine@gmail.com', '09788765234', NULL, NULL, '2018-05-16 03:00:00');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categorysound`
--
ALTER TABLE `categorysound`
  ADD CONSTRAINT `fk_sounds_has_categories_categories1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sounds_has_categories_sounds1` FOREIGN KEY (`sound_id`) REFERENCES `sounds` (`sound_id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `fk_rentals_customers` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rentals_sounds1` FOREIGN KEY (`sound_id`) REFERENCES `sounds` (`sound_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rentals_vendors1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`vendor_id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `sounds`
--
ALTER TABLE `sounds`
  ADD CONSTRAINT `fk_sounds_vendors1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`vendor_id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
