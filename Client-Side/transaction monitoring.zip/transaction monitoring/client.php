<!DOCTYPE HTML>  
<html>
<head>
</head>
<link rel="stylesheet" href="style.css"/>
<body> 
<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//Select the tables by name
$sql = 'SELECT rental_id, rental_date, return_date, status, name 
			FROM rentals INNER JOIN sounds ON rentals.sound_id=sounds.sound_id '; //INNER JOIN for sounds table and rentals table

//database			
mysqli_select_db($conn, 'audirentur');
$query = mysqli_query($conn, $sql);

if(!$query ) {
            die('Could not display data: ' . mysql_error()); //display errors
            }
?> 
<html>
	<body>
	<head>
		<title>Rental</title>
	<style type="text/css"> <!--Temporarily style for tables-->
		body {
			font-size: 15px;
			color: #343d44;
			font-family: "segoe-ui", "open-sans", tahoma, arial;
			padding: 0;
			margin: 0;
		}
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;
			text-align:center;
			width:50%;
		}

		h1 {
			margin: 25px auto 0;
			text-align: center;
			text-transform: uppercase;
			font-size: 17px;
		}

		table td {
			transition: all .5s;
		}
		
		/* Table */
		.data-table {
			margin-top:20px;
			border-collapse: collapse;
			font-size: 14px;
			min-width: 537px;
		}

		.data-table th, 
		.data-table td {
			border: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.data-table caption {
			margin: 7px;
		}

		/* Table Header */
		.data-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}

		/* Table Body */
		.data-table tbody td {
			color: #353535;
		}
		.data-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.data-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
		}
	</style>
</head>
			<table class="data-table">
			<thead>
				<tr>
					<th width="10%">Name</th>
					<th width="5%">Rental Date</th>
					<th width="5%">Return Date</th>
					<th width="5%">Status</th>
				</tr>
			</thead>
			<tbody>
			<?php	//for the data will be displayed
				$no=1;
				while ($row = mysqli_fetch_array($query)){
				echo '<tr>
						<td >'.$row['name'].'</td>
						<td >'.$row['rental_date'].'</td>
						<td >'.$row['return_date'].'</td>
						<td>'.$row['status'].'</td>
					</tr>';
					$no++;
				}?>
			</tbody>	
			</table>
			</body>
		</html>